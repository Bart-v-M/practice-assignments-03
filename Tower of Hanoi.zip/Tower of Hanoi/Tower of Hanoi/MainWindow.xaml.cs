﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tower_of_Hanoi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Disc status (which disc is on top of which tower?)
        bool disc1_onTop_tower1 = true;
        bool disc2_onTop_tower1 = false;
        bool disc3_onTop_tower1 = false;
        bool disc4_onTop_tower1 = false;
        bool disc5_onTop_tower1 = false;
        bool disc6_onTop_tower1 = false;
        bool disc7_onTop_tower1 = false;
        bool disc8_onTop_tower1 = false;

        bool disc1_onTop_tower2 = false;
        bool disc2_onTop_tower2 = false;
        bool disc3_onTop_tower2 = false;
        bool disc4_onTop_tower2 = false;
        bool disc5_onTop_tower2 = false;
        bool disc6_onTop_tower2 = false;
        bool disc7_onTop_tower2 = false;
        bool disc8_onTop_tower2 = false;

        bool disc1_onTop_tower3 = false;
        bool disc2_onTop_tower3 = false;
        bool disc3_onTop_tower3 = false;
        bool disc4_onTop_tower3 = false;
        bool disc5_onTop_tower3 = false;
        bool disc6_onTop_tower3 = false;
        bool disc7_onTop_tower3 = false;
        bool disc8_onTop_tower3 = false;

        // Lists with tower occupations
        List<byte> discs_tower1 = new List<byte>() { 1, 2, 3, 4, 5, 6, 7, 8 };
        List<byte> discs_tower2 = new List<byte>();
        List<byte> discs_tower3 = new List<byte>();

        // Checklist
        List<byte> checkList = new List<byte>() { 1, 2, 3, 4, 5, 6, 7, 8 };

        // Number of discs for the towers
        byte numOfDiscs_tower1 = 8;
        byte numOfDiscs_tower2 = 0;
        byte numOfDiscs_tower3 = 0;

       
        // CHANGE TOWER OCCUPATION
        private void ChangeTowerOccupation(byte discNr, byte towerNr_new)
        {
            // First remove dice from the tower it comes from
            if (discs_tower1.Contains(discNr)) { discs_tower1.Remove(discNr); }
            if (discs_tower2.Contains(discNr)) { discs_tower2.Remove(discNr); }
            if (discs_tower3.Contains(discNr)) { discs_tower3.Remove(discNr); }

            // Add dice to new tower
            if (towerNr_new == 1) { discs_tower1.Add(discNr); }
            if (towerNr_new == 2) { discs_tower2.Add(discNr); }
            if (towerNr_new == 3) { discs_tower3.Add(discNr); }

            // Count number of dice on the towers
            numOfDiscs_tower1 = Convert.ToByte(discs_tower1.Count());
            numOfDiscs_tower2 = Convert.ToByte(discs_tower2.Count());
            numOfDiscs_tower3 = Convert.ToByte(discs_tower3.Count());

            // Reset and update dice status
            ResetDiscStatus();
            UpdateDiscStatus();

            // For testing purposes
            /*MessageBox.Show("tower 1: " + numOfDiscs_tower1
                           + Environment.NewLine
                           + "tower 2: " + numOfDiscs_tower2
                           + Environment.NewLine
                           + "tower 3: " + numOfDiscs_tower3);*/ 
            
        }

        // Reset dice status for tower number
        private void ResetDiscStatus()
        {
            // Tower 1
            disc1_onTop_tower1 = false;
            disc2_onTop_tower1 = false;
            disc3_onTop_tower1 = false;
            disc4_onTop_tower1 = false;
            disc5_onTop_tower1 = false;
            disc6_onTop_tower1 = false;
            disc7_onTop_tower1 = false;
            disc8_onTop_tower1 = false;

            // Tower 2
            disc1_onTop_tower2 = false;
            disc2_onTop_tower2 = false;
            disc3_onTop_tower2 = false;
            disc4_onTop_tower2 = false;
            disc5_onTop_tower2 = false;
            disc6_onTop_tower2 = false;
            disc7_onTop_tower2 = false;
            disc8_onTop_tower2 = false;

            // Tower 3
            disc1_onTop_tower3 = false;
            disc2_onTop_tower3 = false;
            disc3_onTop_tower3 = false;
            disc4_onTop_tower3 = false;
            disc5_onTop_tower3 = false;
            disc6_onTop_tower3 = false;
            disc7_onTop_tower3 = false;
            disc8_onTop_tower3 = false;
        }

        // Change dice status
        private void UpdateDiscStatus()
        {
            // Tower 1
            if (numOfDiscs_tower1 != 0)
            {
                if (discs_tower1.Min() == 1) { disc1_onTop_tower1 = true; }
                if (discs_tower1.Min() == 2) { disc2_onTop_tower1 = true; }
                if (discs_tower1.Min() == 3) { disc3_onTop_tower1 = true; }
                if (discs_tower1.Min() == 4) { disc4_onTop_tower1 = true; }
                if (discs_tower1.Min() == 5) { disc5_onTop_tower1 = true; }
                if (discs_tower1.Min() == 6) { disc6_onTop_tower1 = true; }
                if (discs_tower1.Min() == 7) { disc7_onTop_tower1 = true; }
                if (discs_tower1.Min() == 8) { disc8_onTop_tower1 = true; }
            }

            // Tower 2
            if (numOfDiscs_tower2 != 0)
            {
                if (discs_tower2.Min() == 1) { disc1_onTop_tower2 = true; }
                if (discs_tower2.Min() == 2) { disc2_onTop_tower2 = true; }
                if (discs_tower2.Min() == 3) { disc3_onTop_tower2 = true; }
                if (discs_tower2.Min() == 4) { disc4_onTop_tower2 = true; }
                if (discs_tower2.Min() == 5) { disc5_onTop_tower2 = true; }
                if (discs_tower2.Min() == 6) { disc6_onTop_tower2 = true; }
                if (discs_tower2.Min() == 7) { disc7_onTop_tower2 = true; }
                if (discs_tower2.Min() == 8) { disc8_onTop_tower2 = true; }
            }

            // Tower 3
            if (numOfDiscs_tower3 != 0)
            {
                if (discs_tower3.Min() == 1) { disc1_onTop_tower3 = true; }
                if (discs_tower3.Min() == 2) { disc2_onTop_tower3 = true; }
                if (discs_tower3.Min() == 3) { disc3_onTop_tower3 = true; }
                if (discs_tower3.Min() == 4) { disc4_onTop_tower3 = true; }
                if (discs_tower3.Min() == 5) { disc5_onTop_tower3 = true; }
                if (discs_tower3.Min() == 6) { disc6_onTop_tower3 = true; }
                if (discs_tower3.Min() == 7) { disc7_onTop_tower3 = true; }
                if (discs_tower3.Min() == 8) { disc8_onTop_tower3 = true; }
            }
        }


        // GAME OVER CHECK
        bool gameOver;
        private void GameOverCheck()
        {
            // Check if game is over or game has to be continued
            // COMMENT: the game is over if all discs are on tower 2 or tower 3.
            
            if (discs_tower2.Contains(8)
                && discs_tower2.Contains(7)
                && discs_tower2.Contains(6)
                && discs_tower2.Contains(5)
                && discs_tower2.Contains(4) 
                && discs_tower2.Contains(3)
                && discs_tower2.Contains(2)
                && discs_tower2.Contains(1))
            {
                gameOver = true;
            }

            if (discs_tower2.Contains(8)
                && discs_tower2.Contains(7)
                && discs_tower2.Contains(6)
                && discs_tower2.Contains(5)
                && discs_tower2.Contains(4)
                && discs_tower3.Contains(3)
                && discs_tower3.Contains(2)
                && discs_tower3.Contains(1))
            {
                gameOver = true;
            }

            // For testing purposes only (if used, the code above should be commented out temporarily)
            /*
            if (discs_tower2.Contains(3)
                && discs_tower2.Contains(2)
                && discs_tower2.Contains(1))
            {
                gameOver = true;
            }

            if (discs_tower3.Contains(3)
                && discs_tower3.Contains(2)
                && discs_tower3.Contains(1))
            {
                gameOver = true;
            }
            */

            if (gameOver)
            {
                MessageBoxResult result =
                   MessageBox.Show("Congratulations, you've completed the tower!"
                                   + Environment.NewLine
                                   + Environment.NewLine
                                   + "Do you want to play again? "
                                   + Environment.NewLine
                                   + "If you choose no, the program will be closed."
                                   , "Play again?", MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    ResetDiscs();
                }
                else
                {
                    Application.Current.Shutdown();
                }
            }
            else
            {
                // Ignore
            }
        }


        // MOVE DISCS
        Rectangle disc;

        private void Move(object sender, MouseEventArgs e)
        {
            Rectangle objectDisc = disc; 
            Point mousePoint = e.GetPosition(this);

            int positionY;
            int actualHeight;
            int marginBottom;

            int positionX;
            int actualWidth;
            int marginRight;

            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (objectDisc != null)
                {
                    // Vertical
                    positionY = (int)mousePoint.Y;
                    actualHeight = (int)Application.Current.MainWindow.Height;
                    marginBottom = actualHeight - (positionY + (int)objectDisc.Height + (int)SystemParameters.CaptionHeight + (int)SystemParameters.BorderWidth + 20);

                    // Horizontal
                    positionX = (int)mousePoint.X;
                    actualWidth = (int)Application.Current.MainWindow.Width;
                    marginRight = actualWidth - (positionX + (int)objectDisc.Width + (int)SystemParameters.CaptionWidth + (int)SystemParameters.BorderWidth);

                    // Move object
                    objectDisc.Margin = new Thickness(positionX, positionY, marginRight, marginBottom);
                }
            }
        }

        // Bools for checking which disc is currently selected
        bool disc1_selected;
        bool disc2_selected;
        bool disc3_selected;
        bool disc4_selected;
        bool disc5_selected;
        bool disc6_selected;
        bool disc7_selected;
        bool disc8_selected;

        // Bool for checking if currently a disc is being moved
        bool discOnTheMove = false;

        private void Disc1_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc1_onTop_tower1 || disc1_onTop_tower2 || disc1_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc1;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc1_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }
        }

        private void Disc2_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc2_onTop_tower1 || disc2_onTop_tower2 || disc2_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc2;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc2_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }      
        }

        private void Disc3_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc3_onTop_tower1 || disc3_onTop_tower2 || disc3_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc3;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc3_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }
        }

        private void Disc4_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc4_onTop_tower1 || disc4_onTop_tower2 || disc4_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc4;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc4_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }
        }

        private void Disc5_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc5_onTop_tower1 || disc5_onTop_tower2 || disc5_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc5;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc5_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }
        }

        private void Disc6_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc6_onTop_tower1 || disc6_onTop_tower2 || disc6_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc6;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc6_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }
        }

        private void Disc7_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc7_onTop_tower1 || disc7_onTop_tower2 || disc7_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc7;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc7_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }
        }

        private void Disc8_MouseMove(object sender, MouseEventArgs e)
        {
            if (disc8_onTop_tower1 || disc8_onTop_tower2 || disc8_onTop_tower3)
            {
                Cursor = Cursors.Hand;

                if (e.LeftButton == MouseButtonState.Pressed && !discOnTheMove)
                {
                    disc = disc8;
                    disc.Focus();
                    Panel.SetZIndex(disc, 100);
                    disc8_selected = true;

                    discOnTheMove = true;
                    Move(sender, e);
                }
            }    
        }


        // MOUSE LEAVE ACTION (Change cursor back to arrow)
        private void Disc1_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc2_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc3_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc4_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc5_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc6_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc7_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }
        private void Disc8_MouseLeave(object sender, MouseEventArgs e) { Cursor = Cursors.Arrow; }


        // DROP DISCS

        // Bool for checking if dice is moved or not (because of the restrictions/rules of the game)
        bool isDiscMoved;

        private void MyGrid_MouseMove(object sender, MouseEventArgs e)
        {
            // Facilitate requested moves
            Move(sender, e);
        }

        // Method for dropping discs on a tower, when mouse left button is released/goes up
        private void MyGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Rectangle objectDisc = disc;
            Point mousePoint = e.GetPosition(this);

            int positionY;
            int actualHeight;
            int marginBottom;

            int positionX;
            int actualWidth;
            int marginRight;

            if (objectDisc != null && !gameOver)
            {
                // Preset
                isDiscMoved = false;

                // Vertical
                positionY = (int)mousePoint.Y;
                actualHeight = (int)Application.Current.MainWindow.Height;
                marginBottom = actualHeight - (positionY + (int)objectDisc.Height + (int)SystemParameters.CaptionHeight + (int)SystemParameters.BorderWidth + 20);

                // Horizontal
                positionX = (int)mousePoint.X;
                actualWidth = (int)Application.Current.MainWindow.Width;
                marginRight = actualWidth - (positionX + (int)objectDisc.Width + (int)SystemParameters.CaptionWidth + (int)SystemParameters.BorderWidth);

                // Move object
                objectDisc.Margin = new Thickness(positionX, positionY, marginRight, marginBottom);

                // If object is in TOWER 1 AREA
                if (objectDisc.Margin.Left >= area_tower1.Margin.Left 
                    && objectDisc.Margin.Left + objectDisc.Width <= area_tower1.Margin.Left + area_tower1.Width
                    && objectDisc.Margin.Top >= area_tower1.Margin.Top 
                    && objectDisc.Margin.Top <= area_tower1.Margin.Top + area_tower1.Height)
                {
                    if (disc1_selected)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(1, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc2_selected
                        && !disc1_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(2, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc3_selected
                        && !disc1_onTop_tower1 && !disc2_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(3, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc4_selected
                        && !disc1_onTop_tower1 && !disc2_onTop_tower1 && !disc3_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(4, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc5_selected
                        && !disc1_onTop_tower1 && !disc2_onTop_tower1 && !disc3_onTop_tower1 && !disc4_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(5, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc6_selected
                        && !disc1_onTop_tower1 && !disc2_onTop_tower1 && !disc3_onTop_tower1 && !disc4_onTop_tower1 
                        && !disc5_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(6, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc7_selected
                      && !disc1_onTop_tower1 && !disc2_onTop_tower1 && !disc3_onTop_tower1 && !disc4_onTop_tower1 
                      && !disc5_onTop_tower1 && !disc6_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(7, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc8_selected
                        && !disc1_onTop_tower1 && !disc2_onTop_tower1 && !disc3_onTop_tower1 && !disc4_onTop_tower1 
                        && !disc5_onTop_tower1 && !disc6_onTop_tower1 && !disc7_onTop_tower1)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(8, 1);
                        PutDiscOnTower(objectDisc, 1);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }
                }

                // If object is in TOWER 2 AREA
                if (objectDisc.Margin.Left >= area_tower2.Margin.Left 
                    && objectDisc.Margin.Left + objectDisc.Width <= area_tower2.Margin.Left + area_tower2.Width
                    && objectDisc.Margin.Top >= area_tower2.Margin.Top 
                    && objectDisc.Margin.Top <= area_tower2.Margin.Top + area_tower2.Height)
                {
                    if (disc1_selected)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(1, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc2_selected
                        && !disc1_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(2, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc3_selected
                        && !disc1_onTop_tower2 && !disc2_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(3, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc4_selected
                        && !disc1_onTop_tower2 && !disc2_onTop_tower2 && !disc3_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(4, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc5_selected
                        && !disc1_onTop_tower2 && !disc2_onTop_tower2 && !disc3_onTop_tower2 && !disc4_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(5, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc6_selected
                        && !disc1_onTop_tower2 && !disc2_onTop_tower2 && !disc3_onTop_tower2 && !disc4_onTop_tower2 
                        && !disc5_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(6, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc7_selected
                      && !disc1_onTop_tower2 && !disc2_onTop_tower2 && !disc3_onTop_tower2 && !disc4_onTop_tower2 
                      && !disc5_onTop_tower2 && !disc6_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(7, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc8_selected
                        && !disc1_onTop_tower2 && !disc2_onTop_tower2 && !disc3_onTop_tower2 && !disc4_onTop_tower2 
                        && !disc5_onTop_tower2 && !disc6_onTop_tower2 && !disc7_onTop_tower2)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(8, 2);
                        PutDiscOnTower(objectDisc, 2);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }
                }

                // If object is in TOWER 3 AREA
                if (objectDisc.Margin.Left >= area_tower3.Margin.Left 
                    && objectDisc.Margin.Left + objectDisc.Width <= area_tower3.Margin.Left + area_tower3.Width
                    && objectDisc.Margin.Top >= area_tower3.Margin.Top 
                    && objectDisc.Margin.Top <= area_tower3.Margin.Top + area_tower3.Height)
                {
                    if (disc1_selected)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(1, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc2_selected
                        && !disc1_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(2, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc3_selected
                        && !disc1_onTop_tower3 && !disc2_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(3, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc4_selected
                        && !disc1_onTop_tower3 && !disc2_onTop_tower3 && !disc3_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(4, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc5_selected
                        && !disc1_onTop_tower3 && !disc2_onTop_tower3 && !disc3_onTop_tower3 && !disc4_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(5, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc6_selected
                        && !disc1_onTop_tower3 && !disc2_onTop_tower3 && !disc3_onTop_tower3 && !disc4_onTop_tower3 
                        && !disc5_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(6, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc7_selected
                       && !disc1_onTop_tower3 && !disc2_onTop_tower3 && !disc3_onTop_tower3 && !disc4_onTop_tower3 
                       && !disc5_onTop_tower3 && !disc6_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(7, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }

                    if (disc8_selected
                        && !disc1_onTop_tower3 && !disc2_onTop_tower3 && !disc3_onTop_tower3 && !disc4_onTop_tower3 
                        && !disc5_onTop_tower3 && !disc6_onTop_tower3 && !disc7_onTop_tower3)
                    {
                        // Change tower occupation and set dice margin
                        ChangeTowerOccupation(8, 3);
                        PutDiscOnTower(objectDisc, 3);
                        isDiscMoved = true;

                        // Reset selected dice
                        ResetDiscs();
                    }
                }

                // If no tower area was available/chosen
                if (isDiscMoved == false)
                {
                    if (disc1_selected)
                    {
                        if (disc1_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc1_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc1_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc2_selected)
                    {
                        if (disc2_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc2_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc2_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc3_selected)
                    {
                        if (disc3_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc3_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc3_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc4_selected)
                    {
                        if (disc4_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc4_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc4_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc5_selected)
                    {
                        if (disc5_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc5_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc5_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc6_selected)
                    {
                        if (disc6_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc6_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc6_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc7_selected)
                    {
                        if (disc7_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc7_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc7_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    if (disc8_selected)
                    {
                        if (disc8_onTop_tower1) { PutDiscOnTower(objectDisc, 1); }
                        if (disc8_onTop_tower2) { PutDiscOnTower(objectDisc, 2); }
                        if (disc8_onTop_tower3) { PutDiscOnTower(objectDisc, 3); }
                    }

                    // Reset selected dice
                    ResetDiscs();
                }
            }

            // Game over check
            GameOverCheck();
        }

        // Reset discs
        private void ResetDiscs()
        {
            // Set selected disc to 'null'
            disc = null;

            // Deselect all discs
            disc1_selected = false;
            disc2_selected = false;
            disc3_selected = false;
            disc4_selected = false;
            disc5_selected = false;
            disc6_selected = false;
            disc7_selected = false;
            disc8_selected = false;

            // Reset Z-index
            Panel.SetZIndex(disc1, 1);
            Panel.SetZIndex(disc2, 1);
            Panel.SetZIndex(disc3, 1);
            Panel.SetZIndex(disc4, 1);
            Panel.SetZIndex(disc5, 1);
            Panel.SetZIndex(disc6, 1);
            Panel.SetZIndex(disc7, 1);
            Panel.SetZIndex(disc8, 1);

            discOnTheMove = false;

            if (gameOver)
            {
                // Put all discs back again on tower 1
                numOfDiscs_tower1 = 1; PutDiscOnTower(disc8, 1);
                numOfDiscs_tower1 = 2; PutDiscOnTower(disc7, 1);
                numOfDiscs_tower1 = 3; PutDiscOnTower(disc6, 1);
                numOfDiscs_tower1 = 4; PutDiscOnTower(disc5, 1);
                numOfDiscs_tower1 = 5; PutDiscOnTower(disc4, 1);
                numOfDiscs_tower1 = 6; PutDiscOnTower(disc3, 1);
                numOfDiscs_tower1 = 7; PutDiscOnTower(disc2, 1);
                numOfDiscs_tower1 = 8; PutDiscOnTower(disc1, 1);

                numOfDiscs_tower2 = 0;
                numOfDiscs_tower3 = 0;

                // Reset lists
                discs_tower1 = new List<byte>() { 1, 2, 3, 4, 5, 6, 7, 8 };
                discs_tower2 = new List<byte>();
                discs_tower3 = new List<byte>();

                // Reset game over status
                gameOver = false;
            }
        }

        // Put disc on tower nr X
        private void PutDiscOnTower(Rectangle objectDisc, byte towerNr)
        {
            // Preset
            byte towerWidth = 10;

            if (towerNr == 1) { objectDisc.Margin = new Thickness(226 + (0.5 * towerWidth) - (0.5 * objectDisc.Width), 481 - (numOfDiscs_tower1 * objectDisc.Height), 0, 0); }
            if (towerNr == 2) { objectDisc.Margin = new Thickness(497 + (0.5 * towerWidth) - (0.5 * objectDisc.Width), 447 - (numOfDiscs_tower2 * objectDisc.Height), 0, 0); }
            if (towerNr == 3) { objectDisc.Margin = new Thickness(771 + (0.5 * towerWidth) - (0.5 * objectDisc.Width), 477 - (numOfDiscs_tower3 * objectDisc.Height), 0, 0); }
        }
    }
}
