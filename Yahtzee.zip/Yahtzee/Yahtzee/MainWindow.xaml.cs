﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

// COMMENT BEFOREHAND: 
// Before you start the program in the debug mode in Visual Studio, make sure that line 1102 has the correct path
// for loading the sound file of the sound with the rolling dice.

namespace Yahtzee
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // GAME TYPE
        enum Gametype
        {
            Alone,
            AgainstEachOther
        }

        // PLAYER NAMES:
        string namePlayer1 = "Player 1";
        string namePlayer2 = "Player 2";

        // PLAYER NUMBER:
        byte playerNr = 1;  // player 1 starts the game, so 'PlayerNr' is set to 1 initially

        // NUMBER OF THROWS LEFT:
        byte throwsLeft = 3;

        public MainWindow()
        {
            InitializeComponent();
            SetStartScreen();
            ThrowDice(5);
            GiveInfo(textBlock_info, "");
        }

        // CLEAR SCREEN
        private void SetStartScreen()
        {
            // Clear all controls not needed at the start of the game
            List<Control> controls = new List<Control>
            {
                selectedDice1_player1, selectedDice2_player1, selectedDice3_player1, selectedDice4_player1, selectedDice5_player1,
                selectedDice1_player2, selectedDice2_player2, selectedDice3_player2, selectedDice4_player2, selectedDice5_player2,
                button_rollDice_player1, button_rollDice_player2,
                tb_namePlayer1, tb_namePlayer2,
                label2_gamestart,
                textBox_namePlayer, textBox_namePlayer2,
                label_startNewGame
            };

            foreach (Control control in controls)
            {
                control.Visibility = Visibility.Collapsed;
            }

            // Clear names on scorecard
            scorecard_columTitle_Player1.Content = "";
            scorecard_columTitle_Player2.Content = "";

            // Set and show necessary controls for gamestart to 'gamestartGrid'
            List<Control> gamestartControls = new List<Control>
            {
                label1_gamestart, label2_gamestart,
                button_gametypeAlone, button_gametypeAgainstEachOther,
                textBox_namePlayer, textBox_namePlayer2
            };

            foreach (Control control in gamestartControls)
            {
                mainGrid.Children.Remove(control);
            }

            gamestartGrid.Children.Clear();

            gamestartGrid.Children.Add(label1_gamestart);
            label1_gamestart.Content = "Choose your game: ";
            label1_gamestart.HorizontalAlignment = HorizontalAlignment.Center;
            label1_gamestart.Visibility = Visibility.Visible;

            gamestartGrid.Children.Add(button_gametypeAlone);
            gamestartGrid.Children.Add(button_gametypeAgainstEachOther);
            button_gametypeAlone.Content = "Play alone";
            button_gametypeAgainstEachOther.Content = "With a friend";
            button_gametypeAlone.Visibility = Visibility.Visible;
            button_gametypeAgainstEachOther.Visibility = Visibility.Visible;
            button_gametypeAlone.HorizontalAlignment = HorizontalAlignment.Center;
            button_gametypeAgainstEachOther.HorizontalAlignment = HorizontalAlignment.Center;
        }

        // GAMETYPE SELECTION:
        Gametype gametype;

        // GAMETYPE BUTTON 'Alone'
        private void Label_gametypeAlone_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Set gametype
            gametype = Gametype.Alone;

            // Remove controls not needed anymore from screen
            button_gametypeAlone.Visibility = Visibility.Collapsed;
            button_gametypeAgainstEachOther.Visibility = Visibility.Collapsed;

            // Set and show necessary controls
            label1_gamestart.Content = "What's your name?";
            gamestartGrid.Children.Add(textBox_namePlayer);
            textBox_namePlayer.Visibility = Visibility.Visible;
            textBox_namePlayer.HorizontalAlignment = HorizontalAlignment.Center;
            textBox_namePlayer.Focus();
        }

        // GAMETYPE BUTTON 'Against each other'
        private void Label_gametypeAgainstEachOther_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Set gametype
            gametype = Gametype.AgainstEachOther;

            // Remove controls not needed anymore from screen
            button_gametypeAlone.Visibility = Visibility.Collapsed;
            button_gametypeAgainstEachOther.Visibility = Visibility.Collapsed;

            // Set and show necessary controls
            label1_gamestart.Content = "What's player 1's name?";
            gamestartGrid.Children.Add(textBox_namePlayer);
            textBox_namePlayer.Visibility = Visibility.Visible;
            textBox_namePlayer.HorizontalAlignment = HorizontalAlignment.Center;
            textBox_namePlayer.Focus();
        }

        // TEXT INPUT name player 1
        private void TextBox_namePlayer_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBox_namePlayer.Text.Length >= 16)
            {
                MessageBox.Show("The maximum number of characters for a name is 16.",
                                "Info", MessageBoxButton.OK, MessageBoxImage.None);
            }

            if (textBox_namePlayer.Text.Length > 0)
            {
                // Create new label for continue button and set properties
                mainGrid.Children.Remove(button_continue);
                Label continueButton = button_continue;

                double topmargin_textBox = textBox_namePlayer.Margin.Top;
                continueButton.Margin = new Thickness(0, topmargin_textBox + 70, 0, 0);

                continueButton.Width = 160;

                continueButton.Height = 37.5;

                continueButton.Content = "Continue";

                continueButton.FontFamily = new FontFamily("Segoe UI Semibold");

                continueButton.FontSize = 16;

                continueButton.Foreground = new SolidColorBrush(Colors.White);

                continueButton.Background = new SolidColorBrush(Colors.RosyBrown);

                continueButton.HorizontalContentAlignment = HorizontalAlignment.Center;

                continueButton.HorizontalAlignment = HorizontalAlignment.Center;

                continueButton.BorderThickness = new Thickness(3);

                var bc = new BrushConverter();
                continueButton.BorderBrush = (Brush)bc.ConvertFrom("#FF302A2A");

                gamestartGrid.Children.Remove(continueButton);
                gamestartGrid.Children.Add(continueButton);
                continueButton.Visibility = Visibility.Visible;
            }
            else
            {
                // Ignore
            }
        }

        // CONTINUE BUTTON
        bool namePlayer1IsGiven = false;

        private void Button_continue_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Gametype 'Alone'
            if (gametype == Gametype.Alone)
            {
                namePlayer1 = textBox_namePlayer.Text;
                StartGame();
            }

            // Gametype 'AgainstEachOther'
            if (gametype == Gametype.AgainstEachOther && namePlayer1IsGiven == true)
            {
                namePlayer2 = textBox_namePlayer.Text;
                StartGame();
            }
            else if (gametype == Gametype.AgainstEachOther && namePlayer1IsGiven == false)
            {
                namePlayer1 = textBox_namePlayer.Text;
                namePlayer1IsGiven = true;

                // Set and show necessary controls
                label1_gamestart.Content = "What's player 2's name?";
                textBox_namePlayer.Text = "";
                textBox_namePlayer.Focus();
            }

            // Remove button from screen
            button_continue.Visibility = Visibility.Collapsed;
        }

        // START GAME
        private void StartGame()
        {
            // Remove and clearing actions
            List<Label> scorecardPlayer1 = new List<Label>
            {
                scorecard_columTitle_Player1, scorecard_Player1_Ones, scorecard_Player1_Twos, scorecard_Player1_Threes, scorecard_Player1_Fours,
                scorecard_Player1_Fives, scorecard_Player1_Sixes, scorecard_Player1_Sum, scorecard_Player1_Bonus, scorecard_Player1_ThreeOfAKind,
                scorecard_Player1_FourOfAKind, scorecard_Player1_FullHouse, scorecard_Player1_SmallStraight, scorecard_Player1_LargeStraight,
                scorecard_Player1_Chance, scorecard_Player1_Yahtzee, scorecard_Player1_TotalScore
            };

            List<Label> scorecardPlayer2 = new List<Label>
            {
                scorecard_columTitle_Player2, scorecard_Player2_Ones, scorecard_Player2_Twos, scorecard_Player2_Threes, scorecard_Player2_Fours,
                scorecard_Player2_Fives, scorecard_Player2_Sixes, scorecard_Player2_Sum, scorecard_Player2_Bonus, scorecard_Player2_ThreeOfAKind,
                scorecard_Player2_FourOfAKind, scorecard_Player2_FullHouse, scorecard_Player2_SmallStraight, scorecard_Player2_LargeStraight,
                scorecard_Player2_Chance, scorecard_Player2_Yahtzee, scorecard_Player2_TotalScore
            };

            if (gametype == Gametype.Alone)
            {
                foreach (Label cell in scorecardPlayer2)
                {
                    cell.Visibility = Visibility.Collapsed;
                }

                foreach (Label cell in scorecardPlayer1)
                {
                    cell.BorderThickness = new Thickness(0.5, 0.5, 2.0, 0.5);
                }

                // Exceptions
                scorecard_columTitle_Player1.BorderThickness = new Thickness(0.5, 2.0, 2.0, 1.0);
                scorecard_Player1_Ones.BorderThickness = new Thickness(0.5, 1.0, 2.0, 0.5);
                scorecard_Player1_Sum.BorderThickness = new Thickness(0.5, 1.5, 2.0, 0.5);
                scorecard_Player1_Bonus.BorderThickness = new Thickness(0.5, 0.5, 2.0, 1.5);
                scorecard_Player1_Yahtzee.BorderThickness = new Thickness(0.5, 0.5, 2.0, 1.0);
                scorecard_Player1_TotalScore.BorderThickness = new Thickness(0.5, 1.0, 2.0, 2.0);
            }
            else
            {
                foreach (Label cell in scorecardPlayer2)
                {
                    cell.Visibility = Visibility.Visible;
                }

                foreach (Label cell in scorecardPlayer1)
                {
                    cell.BorderThickness = new Thickness(0.5, 0.5, 0.5, 0.5);
                }

                // Exceptions
                scorecard_columTitle_Player1.BorderThickness = new Thickness(0.5, 2.0, 0.5, 1.0);
                scorecard_Player1_Ones.BorderThickness = new Thickness(0.5, 1.0, 0.5, 0.5);
                scorecard_Player1_Sum.BorderThickness = new Thickness(0.5, 1.5, 0.5, 0.5);
                scorecard_Player1_Bonus.BorderThickness = new Thickness(0.5, 0.5, 0.5, 1.5);
                scorecard_Player1_Yahtzee.BorderThickness = new Thickness(0.5, 0.5, 0.5, 1.0);
                scorecard_Player1_TotalScore.BorderThickness = new Thickness(0.5, 1.0, 0.5, 2.0);
            }

            List<Control> controls = new List<Control>
            {
                label1_gamestart, label2_gamestart, textBox_namePlayer, textBox_namePlayer2, button_continue
            };

            foreach (Control control in controls)
            {
                control.Visibility = Visibility.Collapsed;
            }

            pitcherGrid.Children.Clear();

            // Set player name(s) on screen
            tb_namePlayer1.Text = namePlayer1;
            tb_namePlayer1.Visibility = Visibility.Visible;
            scorecard_columTitle_Player1.Content = namePlayer1;

            if (gametype != Gametype.Alone)
            {
                tb_namePlayer2.Text = namePlayer2;
                tb_namePlayer2.Visibility = Visibility.Visible;
                scorecard_columTitle_Player2.Content = namePlayer2;
            }
            else
            {
                // Ignore
            }

            // Give dice to player 1 and show 'roll dice' button
            GiveDiceToPlayer(1);

            // Give info
            if (gametype != Gametype.Alone)
            {
                GiveInfo(textBlock_info,
                         $"{namePlayer1} may roll the dice to start the game!"
                         + Environment.NewLine
                         + Environment.NewLine
                         + $"You have {throwsLeft} throws left.");
            }
            else
            {
                GiveInfo(textBlock_info,
                         "Now you may roll the dice to start the game!"
                         + Environment.NewLine
                         + Environment.NewLine
                         + $"You have {throwsLeft} throws left.");
            }

            // Reset
            namePlayer1IsGiven = false;
        }


        // GIVE ALL DICE TO PLAYER
        private void GiveDiceToPlayer(byte PlayerNr)
        {
            throwsLeft = 3;

            List<Control> controlsPlayer1 = new List<Control>
            {
                selectedDice1_player1, selectedDice2_player1, selectedDice3_player1, selectedDice4_player1, selectedDice5_player1,
                button_rollDice_player1
            };

            List<Control> controlsPlayer2 = new List<Control>
            {
                selectedDice1_player2, selectedDice2_player2, selectedDice3_player2, selectedDice4_player2, selectedDice5_player2,
                button_rollDice_player2
            };

            if (playerNr == 1)
            {
                foreach (Control control in controlsPlayer1)
                {
                    control.Visibility = Visibility.Visible;
                }

                foreach (Control control in controlsPlayer2)
                {
                    control.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                foreach (Control control in controlsPlayer1)
                {
                    control.Visibility = Visibility.Collapsed;
                }

                foreach (Control control in controlsPlayer2)
                {
                    control.Visibility = Visibility.Visible;
                }
            }
        }

        // REMOVE PLAYERS DICE (used after first throw)
        private void RemoveSelectedDice(byte playerNr)
        {
            List<Label> dicePlayer1 = new List<Label>
            {
                selectedDice1_player1, selectedDice2_player1, selectedDice3_player1, selectedDice4_player1, selectedDice5_player1
            };

            List<Label> dicePlayer2 = new List<Label>
            {
                selectedDice1_player2, selectedDice2_player2, selectedDice3_player2, selectedDice4_player2, selectedDice5_player2
            };

            if (playerNr == 1)
            {
                foreach (Label dice in dicePlayer1)
                {
                    dice.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                foreach (Label dice in dicePlayer2)
                {
                    dice.Visibility = Visibility.Collapsed;
                }
            }
        }

        // GIVE INFORMATION AND/OR INSTRUCTIONS:
        private void GiveInfo(TextBlock textblock, string info)
        {
            textblock.Text = info;
        }

        // COUNTER FOR NUMBER OF DICE TO THROW
        byte numOfDiceToThrow = 5;
        byte numOfDiceSelected = 0;

        // ROLL DICE BUTTON PLAYER 1 
        private void Button_rollDice_player1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ClickRollDiceButton(1);
        }

        // ROLL DICE BUTTON PLAYER 2
        private void Button_rollDice_player2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (gametype == Gametype.AgainstEachOther)
            {
                ClickRollDiceButton(2);
            }
            else
            {
                // Ignore
            }
        }

        // CLICK ROLL DICE BUTTON
        private void ClickRollDiceButton(byte playerNr)
        {
            if (throwsLeft > 0)
            {
                if (throwsLeft >= 3)
                {
                    RemoveSelectedDice(playerNr);
                }

                throwsLeft -= 1;
                numOfDiceToThrow = Convert.ToByte(5 - numOfDiceSelected);

                ClearUnselectedMoves(playerNr);
                ThrowDice(numOfDiceToThrow);
                PlayDiceSound();
                ShowPossibleMoves();

                // INFORMATION & INSTRUCTIONS SCRIPT:

                // If more than one throw left and YAHTZEE == FALSE
                if (throwsLeft > 1 && yahtzee == false)
                {
                    if (gametype != Gametype.Alone)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                             "Click the dice you want to keep and throw again, or select your move by clicking a cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                             "Click the dice you want to keep and throw again, or select your move by clicking a cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                         "Click the dice you want to keep and throw again, or select your move by clicking a cell on the scorecard."
                         + Environment.NewLine
                         + Environment.NewLine
                         + $"You have {throwsLeft} throws left.");
                    }
                }

                // If more than one throw left and YAHTZEE = TRUE
                if (throwsLeft > 1 && yahtzee == true)
                {
                    if (gametype != Gametype.Alone)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                             $"YAHTZEE for {namePlayer1}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select the Yahtzee by clicking the cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                              $"YAHTZEE for {namePlayer2}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select the Yahtzee by clicking the cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                             "YAHTZEE!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select the Yahtzee by clicking the cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"You have {throwsLeft} throws left.");
                    }
                }

                // If more than one throw left and extraYahtzeeException == TRUE
                if (throwsLeft > 1 && extraYahtzee == true)
                {
                    if (gametype == Gametype.AgainstEachOther)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                             $"YAHTZEE for {namePlayer1}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                             + Environment.NewLine
                             + "The Yahtzee also counts as a joker for other moves."
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select your move by clicking a cell on the scorecard"
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                             $"YAHTZEE for {namePlayer2}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                             + Environment.NewLine
                             + "The Yahtzee also counts as a joker for other moves."
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select your move by clicking a cell on the scorecard"
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                    else if (gametype == Gametype.Alone)
                    {
                        GiveInfo(textBlock_info,
                         "YAHTZEE!!!"
                         + Environment.NewLine
                         + Environment.NewLine
                         + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                         + Environment.NewLine
                         + "The Yahtzee also counts as a joker for other moves."
                         + Environment.NewLine
                         + Environment.NewLine
                         + "You can select your move by clicking a cell on the scorecard"
                         + Environment.NewLine
                         + Environment.NewLine
                         + $"You have {throwsLeft} throws left.");
                    }
                }

                // If one throw left and YAHTZEE = FALSE
                if (throwsLeft == 1 && yahtzee == false)
                {
                    if (gametype != Gametype.Alone)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                             "Click the dice you want to keep and throw again, or select your move by clicking a cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throw left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                             "Click the dice you want to keep and throw again, or select your move by clicking a cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throw left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                             "Click the dice you want to keep and throw again, or select your move by clicking a cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"You have {throwsLeft} throw left.");
                    }
                }

                // If one throw left and YAHTZEE = TRUE
                if (throwsLeft == 1 && yahtzee == true)
                {
                    if (gametype != Gametype.Alone)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                             $"YAHTZEE for {namePlayer1}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select the Yahtzee by clicking the cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throw left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                              $"YAHTZEE for {namePlayer2}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select the Yahtzee by clicking the cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throw left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                         "YAHTZEE!!!"
                         + Environment.NewLine
                         + Environment.NewLine
                         + "You can select the Yahtzee by clicking the cell on the scorecard."
                         + Environment.NewLine
                         + Environment.NewLine
                         + $"You have {throwsLeft} throw left.");
                    }
                }

                // If one throw left and extraYahtzeeException = TRUE
                if (throwsLeft == 1 && extraYahtzee == true)
                {
                    if (gametype == Gametype.AgainstEachOther)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                             $"YAHTZEE for {namePlayer1}!!!"
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                             + Environment.NewLine
                             + "The Yahtzee also counts as a joker for other moves."
                             + Environment.NewLine
                             + Environment.NewLine
                             + "You can select your move by clicking a cell on the scorecard"
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                              $"YAHTZEE for {namePlayer2}!!!"
                              + Environment.NewLine
                              + Environment.NewLine
                              + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                              + Environment.NewLine
                              + "The Yahtzee also counts as a joker for other moves."
                              + Environment.NewLine
                              + Environment.NewLine
                              + "You can select your move by clicking a cell on the scorecard"
                              + Environment.NewLine
                              + Environment.NewLine
                              + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                }
           
                // If zero throws left and YAHTZEE = FALSE
                if (throwsLeft == 0 && yahtzee == false)
                {
                    if (gametype == Gametype.AgainstEachOther)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                            "Select your move by clicking a cell on the scorecard."
                            + Environment.NewLine
                            + Environment.NewLine
                            + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                             "Select your move by clicking a cell on the scorecard."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                            "Select your move by clicking a cell on the scorecard."
                            + Environment.NewLine
                            + Environment.NewLine
                            + $"You have {throwsLeft} throws left.");
                    }
                }

                // If zero throws left and YAHTZEE = TRUE
                if (throwsLeft == 0 && yahtzee == true)
                {
                    if (gametype == Gametype.AgainstEachOther)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                            $"YAHTZEE for {namePlayer1}!!!"
                            + Environment.NewLine
                            + Environment.NewLine
                            + "You can select the Yahtzee by clicking the cell on the scorecard."
                            + Environment.NewLine
                            + Environment.NewLine
                            + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                            $"YAHTZEE for {namePlayer2}!!!"
                            + Environment.NewLine
                            + Environment.NewLine
                            + "You can select the Yahtzee by clicking the cell on the scorecard."
                            + Environment.NewLine
                            + Environment.NewLine
                            + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                        "YAHTZEE!!!"
                        + Environment.NewLine
                        + Environment.NewLine
                        + "You can select the Yahtzee by clicking the cell on the scorecard."
                        + Environment.NewLine
                        + Environment.NewLine
                        + $"You have {throwsLeft} throws left.");
                    }
                }

                // If zero throws left and extraYahtzeeException = TRUE
                if (throwsLeft == 0 && extraYahtzee == true)
                {
                    if (gametype == Gametype.AgainstEachOther)
                    {
                        if (playerNr == 1)
                        {
                            GiveInfo(textBlock_info,
                            $"YAHTZEE for {namePlayer1}!!!"
                            + Environment.NewLine
                            + Environment.NewLine
                            + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                            + Environment.NewLine
                            + "The Yahtzee also counts as a joker for other moves."
                            + Environment.NewLine
                            + Environment.NewLine
                            + "Select your move by clicking a cell on the scorecard"
                            + Environment.NewLine
                            + Environment.NewLine
                            + $"{namePlayer1} has {throwsLeft} throws left.");
                        }
                        else
                        {
                            GiveInfo(textBlock_info,
                            $"YAHTZEE for {namePlayer2}!!!"
                            + Environment.NewLine
                            + Environment.NewLine
                            + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                            + Environment.NewLine
                            + "The Yahtzee also counts as a joker for other moves."
                            + Environment.NewLine
                            + Environment.NewLine
                            + "Select your move by clicking a cell on the scorecard"
                            + Environment.NewLine
                            + Environment.NewLine
                            + $"{namePlayer2} has {throwsLeft} throws left.");
                        }
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                        "YAHTZEE!!!"
                        + Environment.NewLine
                        + Environment.NewLine
                        + "You've thrown an additional Yahtzee and receive 100 bonus points in the Yahtzee box!"
                        + Environment.NewLine
                        + "The Yahtzee also counts as a joker for other moves."
                        + Environment.NewLine
                        + Environment.NewLine
                        + "Select your move by clicking a cell on the scorecard"
                        + Environment.NewLine
                        + Environment.NewLine
                        + $"You have {throwsLeft} throws left.");
                    }
                }
            }
        }

        // CHANGE TURN
        private void ChangeTurn()
        {
            // Remove dice from pitcher
            pitcherGrid.Children.Clear();

            bool player1;
            if (gametype != Gametype.Alone)
            {
                // Set bool to change player
                if (playerNr == 1)
                {
                    player1 = false;
                }
                else
                {
                    player1 = true;
                }

                // Change player
                if (player1)
                {
                    playerNr = 1;
                }
                else
                {
                    playerNr = 2;
                }
            }
            else
            {
                playerNr = 1;
            }

            // Give dice to player, reset throws and number of dice to throw, clear list of selected dice
            GiveDiceToPlayer(playerNr);
            throwsLeft = 3;
            numOfDiceToThrow = 5;
            numOfDiceSelected = 0;
            numOfPipsSelectedDice.Clear();

            // Give info
            if (gametype != Gametype.Alone)
            {
                if (playerNr == 1)
                {
                    GiveInfo(textBlock_info,
                             $"Now it's the turn of {namePlayer1}."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer1} has {throwsLeft} throws left.");
                }
                else
                {
                    GiveInfo(textBlock_info,
                              $"Now it's the turn of {namePlayer2}."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"{namePlayer2} has {throwsLeft} throws left.");
                }
            }
            else
            {
                GiveInfo(textBlock_info,
                             "It's a new turn now."
                             + Environment.NewLine
                             + Environment.NewLine
                             + $"You have {throwsLeft} throws left.");
            }
        }


        // RESOURCE ACCESSOR (used get images for pips on dice)
        internal static class ResourceAccessor
        {
            public static Uri Get(string resourcePath)
            {
                var uri = string.Format
                    ("pack://application:,,,/{0};component/{1}"
                     , Assembly.GetExecutingAssembly().GetName().Name
                     , resourcePath);

                return new Uri(uri);
            }
        }


        // THROW DICE METHOD

        // Array to administrate the number of pips per thrown dice
        byte[] numOfPipsThrownDice = new byte[5];

        // List to administrate the row and column combination used in the pitcher grid
        List<byte> rowColumn = new List<byte>();

        // Random type variable for getting a number of pips at random
        Random random = new Random();

        // Dice label to assign different dices
        Label dice = new Label();

        // Bools to check which dice labels are used
        bool dice1Used;
        bool dice2Used;
        bool dice3Used;
        bool dice4Used;
        bool dice5Used;

        // THROW DICE
        private void ThrowDice(byte numOfDiceToThrow)
        {
            numOfPipsThrownDice = new byte[] { 0, 0, 0, 0, 0 };

            // Create 5 labels for dice
            List<Label> diceLabels = new List<Label>() { diceNr1, diceNr2, diceNr3, diceNr4, diceNr5 };

            // Remove dice labels from the main grid
            foreach (Label dice in diceLabels)
            {
                mainGrid.Children.Remove(dice);
            }

            // (Re)set dice used bools to false
            dice1Used = false; dice2Used = false; dice3Used = false; dice4Used = false; dice5Used = false;

            // Clear 'pitcher' grid, to facilitate a new dice throw action 
            pitcherGrid.Children.Clear();

            // Clear list with saved rows and colums for dice labels in pitcher grid
            rowColumn.Clear();

            // Throw action
            for (byte i = 0; i < numOfDiceToThrow; i++)
            {
                // Number of pips (from 1 to 6) determined at random and added to the list 
                byte pips = Convert.ToByte(random.Next(1, 7));
                numOfPipsThrownDice[i] = pips;

                // The five dice that can be assigned
                if (i == 0) { dice = diceNr1; dice1Used = true; }
                if (i == 1) { dice = diceNr2; dice2Used = true; }
                if (i == 2) { dice = diceNr3; dice3Used = true; }
                if (i == 3) { dice = diceNr4; dice4Used = true; }
                if (i == 4) { dice = diceNr5; dice5Used = true; }

                // Set dice properties
                SetDiceProperties1(dice, numOfPipsThrownDice[i]);

                // Make dice visible in the pitcher
                dice.Visibility = Visibility.Visible;
            }
        }


        // SET DICE PROPERTIES

        byte i; // instance number

        private void SetDiceProperties1(Label dice, byte numOfPips)
        {
            // Basic properties
            dice.Width = 38;
            dice.Height = 38;
            dice.HorizontalAlignment = HorizontalAlignment.Center;
            dice.VerticalAlignment = VerticalAlignment.Center;
            dice.Margin = new Thickness(0, 0, 0, 0);
            dice.Padding = new Thickness(0, 0, 0, 0);

            // Creation of imagebrush for adding image of pips to the dice label
            ImageBrush pipsImage = new ImageBrush
            {
                Stretch = Stretch.Fill
            };

            // Determine corresponding instance number
            if (dice == diceNr1) { i = 0; }
            if (dice == diceNr2) { i = 1; }
            if (dice == diceNr3) { i = 2; }
            if (dice == diceNr4) { i = 3; }
            if (dice == diceNr5) { i = 4; }

            // If number of pips = 1
            if (numOfPipsThrownDice[i] == 1)
            { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice1.png")); }

            // If number of pips = 2 
            if (numOfPipsThrownDice[i] == 2)
            {
                int image = random.Next(0, 2);
                if (image == 0) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice2.png")); }
                if (image == 1) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice2r.png")); } // reversed image
            }

            // If number of pips = 3
            if (numOfPipsThrownDice[i] == 3)
            {
                int image = random.Next(0, 2);
                if (image == 0) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice3.png")); }
                if (image == 1) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice3r.png")); } // reversed image
            }

            // If number of pips = 4
            if (numOfPipsThrownDice[i] == 4)
            { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice4.png")); }

            // If number of pips = 5
            if (numOfPipsThrownDice[i] == 5)
            { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice5.png")); }

            // If number of pips = 6
            if (numOfPipsThrownDice[i] == 6)
            {
                int image = random.Next(0, 2);
                if (image == 0) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice6.png")); }
                if (image == 1) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice6r.png")); } // reversed image
            }

            // Set loaded image of pips as label background
            dice.Background = pipsImage;

            // Rotate dice at random
            sbyte r1 = Convert.ToSByte(random.Next(-9, 10));
            sbyte r2 = Convert.ToSByte(random.Next(-9, 10));
            sbyte r3 = Convert.ToSByte(random.Next(-9, 10));
            RotateTransform rotation = new RotateTransform(r1, r2, r3);
            dice.RenderTransform = rotation;

            // Determine a row column combination (in the pitcher grid) at random (without repeat), and add to list
            byte row;
            byte column;
            string n;
            byte rc;

            do
            {
                row = Convert.ToByte(random.Next(1, 6));
                column = Convert.ToByte(random.Next(1, 5));
                n = row.ToString() + column.ToString();
                rc = Convert.ToByte(n);
            }
            while (row == 1 && column != 2 && column != 3
                   || row == 5 && column != 2 && column != 3
                   || rowColumn.Contains(rc));

            rowColumn.Add(rc);

            // Use row and column determined to set the dice element in the pitcher grid
            string r = rc.ToString().Substring(0, 1);
            string c = rc.ToString().Substring(1, 1);

            Grid.SetRow(dice, Convert.ToByte(r));
            Grid.SetColumn(dice, Convert.ToByte(c));
            pitcherGrid.Children.Add(dice);
        }

        // PLAY SOUND   
        private void PlayDiceSound()
        {
            SoundPlayer player = new SoundPlayer("Z:/OneDrive/Documenten/Programs/IT Vitae Practice Assignments/Red Assignments/Yahtzee/Yahtzee/Dice/MANYDICE.WAV");

            if (numOfDiceToThrow > 1)
            {
                player.PlaySync();
            }
            else
            {
                // OPTION: If available here another sound could be played with only 1 dice that is thrown
                player.PlaySync();
            }

            player.Stop();
        }

        // SELECT THROWN DICE METHOD
        List<byte> numOfPipsSelectedDice = new List<byte>();

        private void SelectThrownDice(Label diceThrown, byte diceNr)
        {
            // Add to number of selected dice
            numOfDiceSelected += 1;

            // Set selected dice from board to 'diceUsed = false'
            if (diceNr == 1) { dice1Used = false; }
            if (diceNr == 2) { dice2Used = false; }
            if (diceNr == 3) { dice3Used = false; }
            if (diceNr == 4) { dice4Used = false; }
            if (diceNr == 5) { dice5Used = false; }

            // Determine which dice is selected and remove from board
            diceThrown.Visibility = Visibility.Collapsed;

            // Determine number of pips and add to list 
            numOfPipsSelectedDice.Add(numOfPipsThrownDice[diceNr - 1]);

            // Add number of pips to name
            diceThrown.Name = $"diceThrown_NumOfPipsIs{numOfPipsSelectedDice[numOfPipsSelectedDice.Count - 1]}";

            // Sort list (highest number of pips first)
            numOfPipsSelectedDice.Sort();
            numOfPipsSelectedDice.Reverse();

            // Load corresponding image of pips for selected dice
            ImageBrush pipsImage1 = new ImageBrush();
            ImageBrush pipsImage2 = new ImageBrush();
            ImageBrush pipsImage3 = new ImageBrush();
            ImageBrush pipsImage4 = new ImageBrush();
            ImageBrush pipsImage5 = new ImageBrush();

            if (numOfDiceSelected >= 1)
            {
                pipsImage1.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[0]}.png"));
            }

            if (numOfDiceSelected >= 2)
            {
                pipsImage2.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[1]}.png"));
            }

            if (numOfDiceSelected >= 3)
            {
                pipsImage3.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[2]}.png"));
            }

            if (numOfDiceSelected >= 4)
            {
                pipsImage4.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[3]}.png"));
            }

            if (numOfDiceSelected >= 5)
            {
                pipsImage5.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[4]}.png"));
            }

            // Change background image and make selected dice visible
            if (playerNr == 1)
            {
                if (numOfDiceSelected >= 1) { selectedDice1_player1.Background = pipsImage1; selectedDice1_player1.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 2) { selectedDice2_player1.Background = pipsImage2; selectedDice2_player1.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 3) { selectedDice3_player1.Background = pipsImage3; selectedDice3_player1.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 4) { selectedDice4_player1.Background = pipsImage4; selectedDice4_player1.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 5) { selectedDice5_player1.Background = pipsImage5; selectedDice5_player1.Visibility = Visibility.Visible; }
            }

            if (playerNr == 2)
            {
                if (numOfDiceSelected >= 1) { selectedDice1_player2.Background = pipsImage1; selectedDice1_player2.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 2) { selectedDice2_player2.Background = pipsImage2; selectedDice2_player2.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 3) { selectedDice3_player2.Background = pipsImage3; selectedDice3_player2.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 4) { selectedDice4_player2.Background = pipsImage4; selectedDice4_player2.Visibility = Visibility.Visible; }
                if (numOfDiceSelected >= 5) { selectedDice5_player2.Background = pipsImage5; selectedDice5_player2.Visibility = Visibility.Visible; }
            }
        }


        // PUT BACK DICE IN PITCHER
        private void PutBackDiceInPitcher(byte selectedDiceNr)
        {
            if (throwsLeft < 3)
            {
                // Change number of dice selected
                numOfDiceSelected -= 1;

                // Determine number of pips of the dice that has to be put back
                byte pips = numOfPipsSelectedDice[selectedDiceNr - 1];

                // Determine which dice is picked and remove from selected dice
                if (playerNr == 1)
                {
                    if (numOfDiceSelected == 4) { selectedDice5_player1.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 3) { selectedDice4_player1.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 2) { selectedDice3_player1.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 1) { selectedDice2_player1.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 0) { selectedDice1_player1.Visibility = Visibility.Collapsed; }
                }

                if (playerNr == 2)
                {
                    if (numOfDiceSelected == 4) { selectedDice5_player2.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 3) { selectedDice4_player2.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 2) { selectedDice3_player2.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 1) { selectedDice2_player2.Visibility = Visibility.Collapsed; }
                    if (numOfDiceSelected == 0) { selectedDice1_player2.Visibility = Visibility.Collapsed; }
                }

                // Find first unused dice label (in order from 1 to 5)
                if (dice1Used == false
                    || (dice1Used == false && dice2Used == false && dice3Used == false && dice4Used == false && dice5Used == false))
                {
                    numOfPipsThrownDice[0] = pips;
                    pitcherGrid.Children.Remove(diceNr1);
                    dice = diceNr1;
                }
                else
                {
                    if (dice2Used == false)
                    {
                        numOfPipsThrownDice[1] = pips;
                        pitcherGrid.Children.Remove(diceNr2);
                        dice = diceNr2;
                    }
                    else
                    {
                        if (dice3Used == false)
                        {
                            numOfPipsThrownDice[2] = pips;
                            pitcherGrid.Children.Remove(diceNr3);
                            dice = diceNr3;
                        }
                        else
                        {
                            if (dice4Used == false)
                            {
                                numOfPipsThrownDice[3] = pips;
                                pitcherGrid.Children.Remove(diceNr4);
                                dice = diceNr4;
                            }
                            else
                            {
                                if (dice5Used == false)
                                {
                                    numOfPipsThrownDice[4] = pips;
                                    pitcherGrid.Children.Remove(diceNr5);
                                    dice = diceNr5;
                                }
                            }
                        }
                    }
                }

                // REORDER SELECTED DICE

                // Remove number of pips from list of selected dice
                numOfPipsSelectedDice.Remove(numOfPipsSelectedDice[selectedDiceNr - 1]);

                // Load corresponding image of pips for remaining selected dice
                ImageBrush pipsImage1 = new ImageBrush();
                ImageBrush pipsImage2 = new ImageBrush();
                ImageBrush pipsImage3 = new ImageBrush();
                ImageBrush pipsImage4 = new ImageBrush();
                ImageBrush pipsImage5 = new ImageBrush();

                if (numOfDiceSelected >= 1)
                {
                    pipsImage1.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[0]}.png"));
                }

                if (numOfDiceSelected >= 2)
                {
                    pipsImage2.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[1]}.png"));
                }

                if (numOfDiceSelected >= 3)
                {
                    pipsImage3.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[2]}.png"));
                }

                if (numOfDiceSelected >= 4)
                {
                    pipsImage4.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[3]}.png"));
                }

                if (numOfDiceSelected >= 5)
                {
                    pipsImage5.ImageSource = new BitmapImage(ResourceAccessor.Get($"Dice/dice{numOfPipsSelectedDice[4]}.png"));
                }

                // Reorder remaining selected dice labels
                if (playerNr == 1)
                {
                    if (numOfDiceSelected >= 1) { selectedDice1_player1.Background = pipsImage1; selectedDice1_player1.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 2) { selectedDice2_player1.Background = pipsImage2; selectedDice2_player1.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 3) { selectedDice3_player1.Background = pipsImage3; selectedDice3_player1.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 4) { selectedDice4_player1.Background = pipsImage4; selectedDice4_player1.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 5) { selectedDice5_player1.Background = pipsImage5; selectedDice5_player1.Visibility = Visibility.Visible; }
                }

                if (playerNr == 2)
                {
                    if (numOfDiceSelected >= 1) { selectedDice1_player2.Background = pipsImage1; selectedDice1_player2.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 2) { selectedDice2_player2.Background = pipsImage2; selectedDice2_player2.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 3) { selectedDice3_player2.Background = pipsImage3; selectedDice3_player2.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 4) { selectedDice4_player2.Background = pipsImage4; selectedDice4_player2.Visibility = Visibility.Visible; }
                    if (numOfDiceSelected >= 5) { selectedDice5_player2.Background = pipsImage5; selectedDice5_player2.Visibility = Visibility.Visible; }
                }

                // PUT BACK DICE

                // Set dice properties
                SetDiceProperties2(dice, pips);

                // Add dice label to list and change bool to 'diceUsed = true'
                if (dice == diceNr1) { dice1Used = true; }
                if (dice == diceNr2) { dice2Used = true; }
                if (dice == diceNr3) { dice3Used = true; }
                if (dice == diceNr4) { dice4Used = true; }
                if (dice == diceNr5) { dice5Used = true; }

                // Make dice visible in the pitcher
                dice.Visibility = Visibility.Visible;
            }
        }

        
        // SET DICE PROPERTIES (second version)
        private void SetDiceProperties2(Label dice, byte numOfPips)
        {
            // Basic properties
            dice.Width = 38;
            dice.Height = 38;
            dice.HorizontalAlignment = HorizontalAlignment.Center;
            dice.VerticalAlignment = VerticalAlignment.Center;
            dice.Margin = new Thickness(0, 0, 0, 0);
            dice.Padding = new Thickness(0, 0, 0, 0);

            // Creation of imagebrush for adding image of pips to the dice label
            ImageBrush pipsImage = new ImageBrush
            {
                Stretch = Stretch.Fill
            };

            // Determine corresponding instance number
            if (dice == diceNr1) { i = 0; }
            if (dice == diceNr2) { i = 1; }
            if (dice == diceNr3) { i = 2; }
            if (dice == diceNr4) { i = 3; }
            if (dice == diceNr5) { i = 4; }

            // If number of pips = 1
            if (numOfPipsThrownDice[i] == 1)
            { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice1.png")); }

            // If number of pips = 2 
            if (numOfPipsThrownDice[i] == 2)
            {
                int image = random.Next(0, 2);
                if (image == 0) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice2.png")); }
                if (image == 1) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice2r.png")); } // reversed image
            }

            // If number of pips = 3
            if (numOfPipsThrownDice[i] == 3)
            {
                int image = random.Next(0, 2);
                if (image == 0) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice3.png")); }
                if (image == 1) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice3r.png")); } // reversed image
            }

            // If number of pips = 4
            if (numOfPipsThrownDice[i] == 4)
            { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice4.png")); }

            // If number of pips = 5
            if (numOfPipsThrownDice[i] == 5)
            { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice5.png")); }

            // If number of pips = 6
            if (numOfPipsThrownDice[i] == 6)
            {
                int image = random.Next(0, 2);
                if (image == 0) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice6.png")); }
                if (image == 1) { pipsImage.ImageSource = new BitmapImage(ResourceAccessor.Get("Dice/dice6r.png")); } // reversed image
            }

            // Set loaded image of pips as label background
            dice.Background = pipsImage;

            // Rotate dice at random
            sbyte r1 = Convert.ToSByte(random.Next(-9, 10));
            sbyte r2 = Convert.ToSByte(random.Next(-9, 10));
            sbyte r3 = Convert.ToSByte(random.Next(-9, 10));
            RotateTransform rotation = new RotateTransform(r1, r2, r3);
            dice.RenderTransform = rotation;

            // Determine a row column combination (in the pitcher grid) at random (without repeat), and add to list
            // IMPORTANT: this method makes sure that each dice always gets an empty space
            byte row;
            byte column;
            string n;
            byte rc;

            do
            {
                row = Convert.ToByte(random.Next(1, 6));
                column = Convert.ToByte(random.Next(1, 5));
                n = row.ToString() + column.ToString();
                rc = Convert.ToByte(n);
            }
            while (row == 1 && column != 2 && column != 3
                   || row == 5 && column != 2 && column != 3
                   || rowColumn.Contains(rc));

            rowColumn.Add(rc);

            // Use row and column determined to set the dice element in the pitcher grid
            string r = rc.ToString().Substring(0, 1);
            string c = rc.ToString().Substring(1, 1);

            Grid.SetRow(dice, Convert.ToInt32(r));
            Grid.SetColumn(dice, Convert.ToInt32(c));
            pitcherGrid.Children.Add(dice);
        }


        // COUNT SCORE AND SHOW POSSIBLE MOVES ON THE SCORECARD
        private void ClearUnselectedMoves(byte playerNr)
        {
            List<Label> scorecardLabels = new List<Label>();

            if (playerNr == 1)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player1_Ones, scorecard_Player1_Twos, scorecard_Player1_Threes, scorecard_Player1_Fours, scorecard_Player1_Fives,
                    scorecard_Player1_Sixes, scorecard_Player1_ThreeOfAKind, scorecard_Player1_FourOfAKind, scorecard_Player1_FullHouse,
                    scorecard_Player1_SmallStraight, scorecard_Player1_LargeStraight, scorecard_Player1_Chance, scorecard_Player1_Yahtzee
                };
            }

            if (playerNr == 2)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player2_Ones, scorecard_Player2_Twos, scorecard_Player2_Threes, scorecard_Player2_Fours, scorecard_Player2_Fives,
                    scorecard_Player2_Sixes, scorecard_Player2_ThreeOfAKind, scorecard_Player2_FourOfAKind, scorecard_Player2_FullHouse,
                    scorecard_Player2_SmallStraight, scorecard_Player2_LargeStraight, scorecard_Player2_Chance, scorecard_Player2_Yahtzee
                };
            }

            // Clear labels if not yet selected
            List<bool> selectedMoves = new List<bool>();
            if (playerNr == 1) { selectedMoves = selectedMoves_Player1; }
            if (playerNr == 2) { selectedMoves = selectedMoves_Player2; }

            for (int i = 0; i < scorecardLabels.Count; i++)
            {
                if (selectedMoves[i] == false)
                {
                    scorecardLabels[i].Content = "";
                }
            }
        }

        // SHOW POSSIBLE MOVES
        bool yahtzee;                          // Checks if a Yahtzee is thrown
        bool extraYahtzee;                     // Checks if an additional Yahtzee is thrown, and the exception rule should be used
        bool correspondingCategoryAvailable;   // Checks, in case of an additional Yahtzee, if the corresponding number category in the upperbox
                                               // of the scorecard is available. In that case the extra Yahtzee must be used here.

        private void ShowPossibleMoves()
        {
            byte numOfOnes = 0; byte numOfTwos = 0; byte numOfThrees = 0; byte numOfFours = 0; byte numOfFives = 0; byte numOfSixes = 0;

            // Presets
            yahtzee = false;
            extraYahtzee = false;
            correspondingCategoryAvailable = false;

            // Count number of pips of thrown dices on the board
            foreach (byte pips in numOfPipsThrownDice)
            {
                if (pips == 1) { numOfOnes++; }
                if (pips == 2) { numOfTwos++; }
                if (pips == 3) { numOfThrees++; }
                if (pips == 4) { numOfFours++; }
                if (pips == 5) { numOfFives++; }
                if (pips == 6) { numOfSixes++; }
            }

            // Count number of pips of selected dices, chosen to hold 
            foreach (int pips in numOfPipsSelectedDice)
            {
                if (pips == 1) { numOfOnes++; }
                if (pips == 2) { numOfTwos++; }
                if (pips == 3) { numOfThrees++; }
                if (pips == 4) { numOfFours++; }
                if (pips == 5) { numOfFives++; }
                if (pips == 6) { numOfSixes++; }
            }

            // Check for Yahtzee (five of a kind) 
            // IMPORTANT: this check needs to be the first in order, in case of the extra Yahtzee exception
            if (numOfOnes == 5 || numOfTwos == 5 || numOfThrees == 5 || numOfFours == 5 || numOfFives == 5 || numOfSixes == 5)
            {
                byte score = new byte();
                string scorecardContent = "";
                string scoreExtraYahtzee = "";

                if (playerNr == 1) { scorecardContent = scorecard_Player1_Yahtzee.Content.ToString(); }
                if (playerNr == 2) { scorecardContent = scorecard_Player2_Yahtzee.Content.ToString(); }

                if (scorecardContent == "")
                {
                    yahtzee = true;
                    score = 50;

                    if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Yahtzee, score); }
                    if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Yahtzee, score); }
                }

                else if (scorecardContent == "0")
                {
                    // Ignore, because Yahtzee is already chosen to be "0".
                }

                else
                {
                    extraYahtzee = true;

                    // Yahtzee box content
                    if (playerNr == 1) { scoreExtraYahtzee = scorecard_Player1_Yahtzee.Content + " + 100!"; }
                    if (playerNr == 2) { scoreExtraYahtzee = scorecard_Player2_Yahtzee.Content + " + 100!"; }

                    if (playerNr == 1) { scorecard_Player1_Yahtzee.Content = scoreExtraYahtzee; }
                    if (playerNr == 2) { scorecard_Player2_Yahtzee.Content = scoreExtraYahtzee; }

                    // List of selected moves
                    List<bool> selectedMoves = new List<bool>();
                    if (playerNr == 1) { selectedMoves = selectedMoves_Player1; }
                    if (playerNr == 2) { selectedMoves = selectedMoves_Player2; }

                    // Check if corresponding number category of Yahtzee is available in upperbox of scorecard
                    if (numOfOnes == 5 && selectedMoves[0] == false
                           || numOfTwos == 5 && selectedMoves[1] == false
                           || numOfThrees == 5 && selectedMoves[2] == false
                           || numOfFours == 5 && selectedMoves[3] == false
                           || numOfFives == 5 && selectedMoves[4] == false
                           || numOfSixes == 5 && selectedMoves[5] == false)
                    {
                        correspondingCategoryAvailable = true;
                    }
                }
            }

            // Check for Ones
            if (numOfOnes > 0)
            {
                byte score = Convert.ToByte(numOfOnes * 1);
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Ones, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Ones, score); }
            }

            // Check for Twos
            if (numOfTwos > 0)
            {
                byte score = Convert.ToByte(numOfTwos * 2);
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Twos, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Twos, score); }
            }

            // Check for Threes
            if (numOfThrees > 0)
            {
                byte score = Convert.ToByte(numOfThrees * 3);
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Threes, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Threes, score); }
            }

            // Check for Fours
            if (numOfFours > 0)
            {
                byte score = Convert.ToByte(numOfFours * 4);
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Fours, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Fours, score); }
            }

            // Check for Fives
            if (numOfFives > 0)
            {
                byte score = Convert.ToByte(numOfFives * 5);
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Fives, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Fives, score); }
            }

            // Check for Sixes
            if (numOfSixes > 0)
            {
                byte score = Convert.ToByte(numOfSixes * 6);
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Sixes, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Sixes, score); }
            }

            // Check for Three of a kind
            if ((numOfOnes >= 3 || numOfTwos >= 3 || numOfThrees >= 3 || numOfFours >= 3 || numOfFives >= 3 || numOfSixes >= 3)
                && correspondingCategoryAvailable == false)
            {
                byte score = Convert.ToByte((numOfOnes * 1) + (numOfTwos * 2) + (numOfThrees * 3) + (numOfFours * 4) + (numOfFives * 5) + (numOfSixes * 6));
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_ThreeOfAKind, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_ThreeOfAKind, score); }
            }

            // Check for Four of a kind 
            if ((numOfOnes >= 4 || numOfTwos >= 4 || numOfThrees >= 4 || numOfFours >= 4 || numOfFives >= 4 || numOfSixes >= 4)
                && correspondingCategoryAvailable == false)
            {
                byte score = Convert.ToByte((numOfOnes * 1) + (numOfTwos * 2) + (numOfThrees * 3) + (numOfFours * 4) + (numOfFives * 5) + (numOfSixes * 6));
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_FourOfAKind, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_FourOfAKind, score); }
            }

            // Check for Full House (three and two of the same dice combined)
            if ((numOfOnes == 3 || numOfTwos == 3 || numOfThrees == 3 || numOfFours == 3 || numOfFives == 3 || numOfSixes == 3)
                && (numOfOnes == 2 || numOfTwos == 2 || numOfThrees == 2 || numOfFours == 2 || numOfFives == 2 || numOfSixes == 2)
                || (extraYahtzee == true && correspondingCategoryAvailable == false))
            {
                byte score = 25;
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_FullHouse, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_FullHouse, score); }
            }

            // Check for Small straight (four sequential dice)
            if ((numOfOnes >= 1 && numOfTwos >= 1 && numOfThrees >= 1 && numOfFours >= 1)
                || (numOfTwos >= 1 && numOfThrees >= 1 && numOfFours >= 1 && numOfFives >= 1)
                || (numOfThrees >= 1 && numOfFours >= 1 && numOfFives >= 1 && numOfSixes >= 1)
                || (extraYahtzee == true && correspondingCategoryAvailable == false))
            {
                byte score = 30;
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_SmallStraight, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_SmallStraight, score); }
            }

            // Check for Large straight (five sequential dice)
            if ((numOfOnes >= 1 && numOfTwos >= 1 && numOfThrees >= 1 && numOfFours >= 1 && numOfFives >= 1)
                || (numOfTwos >= 1 && numOfThrees >= 1 && numOfFours >= 1 && numOfFives >= 1 && numOfSixes >= 1)
                || (extraYahtzee == true && correspondingCategoryAvailable == false))
            {
                byte score = 40;
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_LargeStraight, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_LargeStraight, score); }
            }

            // Check for Chance (every combination of dice is possible)
            bool chance = true;
            if (chance && correspondingCategoryAvailable == false)
            {
                byte score = Convert.ToByte((numOfOnes * 1) + (numOfTwos * 2) + (numOfThrees * 3) + (numOfFours * 4) + (numOfFives * 5) + (numOfSixes * 6));
                if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Chance, score); }
                if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Chance, score); }
            }

            // Check if there are move possible that generate points
            CheckForPossibleMoves();
        }


        // CHECK FOR POSSIBLE MOVES
        bool areTherePossibleMoves;
        private void CheckForPossibleMoves()
        {
            // List of all scorecard labels
            List<Label> scorecardLabels = new List<Label>();

            if (playerNr == 1)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player1_Ones, scorecard_Player1_Twos, scorecard_Player1_Threes,
                    scorecard_Player1_Fours, scorecard_Player1_Fives, scorecard_Player1_Sixes,
                    scorecard_Player1_ThreeOfAKind, scorecard_Player1_FourOfAKind, scorecard_Player1_FullHouse,
                    scorecard_Player1_SmallStraight, scorecard_Player1_LargeStraight, scorecard_Player1_Chance,
                    scorecard_Player1_Yahtzee
                };
            }

            if (playerNr == 2)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player2_Ones, scorecard_Player2_Twos, scorecard_Player2_Threes,
                    scorecard_Player2_Fours, scorecard_Player2_Fives, scorecard_Player2_Sixes,
                    scorecard_Player2_ThreeOfAKind, scorecard_Player2_FourOfAKind, scorecard_Player2_FullHouse,
                    scorecard_Player2_SmallStraight, scorecard_Player2_LargeStraight, scorecard_Player2_Chance,
                    scorecard_Player2_Yahtzee
                };
            }

            // Count all possible moves
            byte count = 0;
            List<bool> selectedMoves = new List<bool>();
            if (playerNr == 1) { selectedMoves = selectedMoves_Player1; }
            if (playerNr == 2) { selectedMoves = selectedMoves_Player2; }

            for (byte i = 0; i < scorecardLabels.Count; i++)
            {
                if (scorecardLabels[i].Content.ToString() != "" && selectedMoves[i] == false)
                {
                    count++;
                }
            }

            // Count one extra, for extra Yahtzee possibility
            if (extraYahtzee)
            {
                count++;
            }

            // Check if there are possible moves or not
            if (count > 0)
            {
                areTherePossibleMoves = true;
            }
            else
            {
                areTherePossibleMoves = false;

                for (int i = 0; i < scorecardLabels.Count; i++)
                {
                    if (scorecardLabels[i].Content.ToString() == "")
                    {
                        byte score = 0;
                        scorecardLabels[i].Content = score.ToString();
                        scorecardLabels[i].Foreground = new SolidColorBrush(Colors.Crimson);
                    }
                }
            }
        }


        // SHOW SCORE CARD CONTENT METHOD
        private void ShowScoreCardContent(Label scorecard, byte score)
        {
            // Preset
            isMoveSelected = false;

            // List of all scorecard labels
            List<Label> scorecardLabels = new List<Label>();

            if (playerNr == 1)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player1_Ones, scorecard_Player1_Twos, scorecard_Player1_Threes,
                    scorecard_Player1_Fours, scorecard_Player1_Fives, scorecard_Player1_Sixes,
                    scorecard_Player1_ThreeOfAKind, scorecard_Player1_FourOfAKind, scorecard_Player1_FullHouse,
                    scorecard_Player1_SmallStraight, scorecard_Player1_LargeStraight, scorecard_Player1_Chance,
                    scorecard_Player1_Yahtzee
                };
            }

            if (playerNr == 2)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player2_Ones, scorecard_Player2_Twos, scorecard_Player2_Threes,
                    scorecard_Player2_Fours, scorecard_Player2_Fives, scorecard_Player2_Sixes,
                    scorecard_Player2_ThreeOfAKind, scorecard_Player2_FourOfAKind, scorecard_Player2_FullHouse,
                    scorecard_Player2_SmallStraight, scorecard_Player2_LargeStraight, scorecard_Player2_Chance,
                    scorecard_Player2_Yahtzee
                };
            }

            // Check if the label clicked on has already been selected before
            List<bool> selectedMoves = new List<bool>();
            if (playerNr == 1) { selectedMoves = selectedMoves_Player1; }
            if (playerNr == 2) { selectedMoves = selectedMoves_Player2; }

            for (byte i = 0; i < scorecardLabels.Count; i++)
            {
                if (scorecard == scorecardLabels[i] && selectedMoves[i] == true)
                {
                    isMoveSelected = true;
                }
            }

            // Check if move is selected, and if true change the content to show 
            // the possible score that will be added when the move is selected
            if (isMoveSelected == false)
            {
                scorecard.Content = score.ToString();

                if (scorecard != scorecard_Player1_Sum && scorecard != scorecard_Player1_Bonus && scorecard != scorecard_Player1_TotalScore
                    && scorecard != scorecard_Player2_Sum && scorecard != scorecard_Player2_Bonus && scorecard != scorecard_Player2_TotalScore)
                {
                    scorecard.Foreground = new SolidColorBrush(Colors.Crimson);
                }
            }
        }

        private void ShowSumOrTotal(Label scorecard, int score)
        {
            scorecard.Content = score.ToString();
            scorecard.Foreground = new SolidColorBrush(Colors.Black);
        }


        // MOUSEDOWN ACTIONS THROWN DICES
        private void DiceNr1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SelectThrownDice(diceNr1, 1);
        }

        private void DiceNr2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SelectThrownDice(diceNr2, 2);
        }

        private void DiceNr3_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SelectThrownDice(diceNr3, 3);
        }

        private void DiceNr4_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SelectThrownDice(diceNr4, 4);
        }

        private void DiceNr5_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SelectThrownDice(diceNr5, 5);
        }


        // MOUSEDOWN ACTIONS SELECTED DICES, PLAYER 1

        private void SelectedDice1_player1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(1);
        }

        private void SelectedDice2_player1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(2);
        }

        private void SelectedDice3_player1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(3);
        }

        private void SelectedDice4_player1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(4);
        }

        private void SelectedDice5_player1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(5);
        }


        // MOUSEDOWN ACTIONS SELECTED DICES, PLAYER 2

        private void SelectedDice1_player2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(1);
        }

        private void SelectedDice2_player2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(2);
        }

        private void SelectedDice3_player2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(3);
        }

        private void SelectedDice4_player2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(4);
        }

        private void SelectedDice5_player2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PutBackDiceInPitcher(5);
        }


        // SCORECARD LABELS MOUSE ACTIONS: ENTER & LEAVE
        private void Scorecard_MouseEnter(object sender, MouseEventArgs e)
        {
            Label scorecard;
            scorecard = (Label)sender;

            List<Label> scorecardLabels = new List<Label>();

            if (playerNr == 1)
            {
                scorecardLabels = new List<Label>()
                {
                    scorecard_Player1_Ones, scorecard_Player1_Twos, scorecard_Player1_Threes, scorecard_Player1_Fours, scorecard_Player1_Fives,
                    scorecard_Player1_Sixes, scorecard_Player1_ThreeOfAKind, scorecard_Player1_FourOfAKind, scorecard_Player1_FullHouse,
                    scorecard_Player1_SmallStraight, scorecard_Player1_LargeStraight, scorecard_Player1_Chance, scorecard_Player1_Yahtzee
                };
            }

            if (playerNr == 2)
            {
                scorecardLabels = new List<Label>()
                {
                    scorecard_Player2_Ones, scorecard_Player2_Twos, scorecard_Player2_Threes, scorecard_Player2_Fours, scorecard_Player2_Fives,
                    scorecard_Player2_Sixes, scorecard_Player2_ThreeOfAKind, scorecard_Player2_FourOfAKind, scorecard_Player2_FullHouse,
                    scorecard_Player2_SmallStraight, scorecard_Player2_LargeStraight, scorecard_Player2_Chance, scorecard_Player2_Yahtzee
                };
            }

            // Change cursor to hand if not yet selected
            List<bool> selectedMoves = new List<bool>();
            if (playerNr == 1) { selectedMoves = selectedMoves_Player1; }
            if (playerNr == 2) { selectedMoves = selectedMoves_Player2; }

            for (int i = 0; i < scorecardLabels.Count; i++)
            {
                if (scorecard == scorecardLabels[i] && selectedMoves[i] == false)
                {
                    Mouse.OverrideCursor = Cursors.Hand;
                }
            }
        }

        private void Scorecard_MouseLeave(object sender, MouseEventArgs e)
        {
            Mouse.OverrideCursor = Cursors.Arrow;
        }


        // SCORE VARIABLES AND BOOLS
        int sumPlayer1; int sumPlayer2;
        bool bonusPlayer1; bool bonusPlayer2;
        int totalPlayer1; int totalPlayer2;

        // List of booleans for checking the 13 possible selected moves in the list of scorecard labels
        List<bool> selectedMoves_Player1 = new List<bool>()
        {
            false, false, false, false, false, false, false, false, false, false, false, false, false
        };

        List<bool> selectedMoves_Player2 = new List<bool>()
        {
            false, false, false, false, false, false, false, false, false, false, false, false, false
        };


        // SELECT MOVE:
        // SCORECARD LABELS MOUSEDOWN ACTIONS
        bool isMoveSelected; // bool for checking if move is already selected
        bool continueMove;   // bool for checking if move has to be continued

        private void Scorecard_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Preset
            isMoveSelected = false;

            // Initialize label object for the label the user has clicked on
            Label scorecard;
            scorecard = (Label)sender;

            // List of all scorecard labels
            List<Label> scorecardLabels = new List<Label>();

            if (playerNr == 1)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player1_Ones, scorecard_Player1_Twos, scorecard_Player1_Threes,
                    scorecard_Player1_Fours, scorecard_Player1_Fives, scorecard_Player1_Sixes,
                    scorecard_Player1_ThreeOfAKind, scorecard_Player1_FourOfAKind, scorecard_Player1_FullHouse,
                    scorecard_Player1_SmallStraight, scorecard_Player1_LargeStraight, scorecard_Player1_Chance,
                    scorecard_Player1_Yahtzee
                };
            }

            if (playerNr == 2)
            {
                scorecardLabels = new List<Label>
                {
                    scorecard_Player2_Ones, scorecard_Player2_Twos, scorecard_Player2_Threes,
                    scorecard_Player2_Fours, scorecard_Player2_Fives, scorecard_Player2_Sixes,
                    scorecard_Player2_ThreeOfAKind, scorecard_Player2_FourOfAKind, scorecard_Player2_FullHouse,
                    scorecard_Player2_SmallStraight, scorecard_Player2_LargeStraight, scorecard_Player2_Chance,
                    scorecard_Player2_Yahtzee
                };
            }

            // Check if the label clicked on has already been selected before
            List<bool> selectedMoves = new List<bool>();
            if (playerNr == 1) { selectedMoves = selectedMoves_Player1; }
            if (playerNr == 2) { selectedMoves = selectedMoves_Player2; }

            for (int i = 0; i < scorecardLabels.Count; i++)
            {
                if (scorecard == scorecardLabels[i] && selectedMoves[i] == true)
                {
                    isMoveSelected = true;
                }

                if (scorecard == scorecardLabels[i] && selectedMoves[i] == false)
                {
                    isMoveSelected = false;
                    selectedMoves[i] = true; // make selected move true now, because move will be selected
                }
            }

            // If not selected before, make selected now and calculate score
            if (isMoveSelected == false)
            {
                // Change foreground (font) to black, to show that the field is selected
                scorecard.Foreground = new SolidColorBrush(Colors.Black);

                // Set corresponding bool for selectioncheck to true
                for (byte i = 0; i < scorecardLabels.Count; i++)
                {
                    if (scorecard == scorecardLabels[i])
                    {
                        selectedMoves[i] = true;
                    }
                }

                // Convert scorecard content to integer for calculation
                int score = new int();
                byte bonuspoints = 35;

                if (scorecard.Content.ToString() == "" && areTherePossibleMoves == true)
                {
                    MessageBoxResult result = MessageBox.Show("This move will give you 0 points. Another move will give you more points. " +
                                                              "Are you sure you want to do this?", "Warning",
                                                              MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.Yes)
                    {
                        score = 0;
                        scorecard.Content = score.ToString();
                        continueMove = true;
                    }
                    else
                    {
                        continueMove = false;

                        for (int i = 0; i < scorecardLabels.Count; i++)
                        {
                            if (scorecard == scorecardLabels[i] && selectedMoves[i] == true)
                            {
                                isMoveSelected = false;
                                selectedMoves[i] = false; // make selected move false again, because it's not selected
                            }
                        }
                    }
                }

                if (scorecard.Content.ToString() == "" && areTherePossibleMoves == false)
                {
                    score = 0;
                    scorecard.Content = score.ToString();
                    continueMove = true;
                }

                if (scorecard.Content.ToString() != "" && extraYahtzee == false)
                {
                    score = Convert.ToInt16(scorecard.Content);
                    continueMove = true;
                }

                // Additional actions concerning extra Yahtzee
                byte firstNumber = new byte();
                if (scorecard.Content.ToString() != "" && extraYahtzee == true)
                {
                    if (playerNr == 1) { firstNumber = Convert.ToByte(scorecard_Player1_Yahtzee.Content.ToString().Substring(0, 1)); }
                    if (playerNr == 2) { firstNumber = Convert.ToByte(scorecard_Player2_Yahtzee.Content.ToString().Substring(0, 1)); }

                    if (firstNumber == 0)
                    {
                        extraYahtzee = false;
                        score = 0;
                        if (playerNr == 1) { scorecard_Player1_Yahtzee.Content = score.ToString(); }
                        if (playerNr == 2) { scorecard_Player2_Yahtzee.Content = score.ToString(); }
                    }
                    else
                    {
                        string currentScore = scorecard_Player1_Yahtzee.Content.ToString().Substring(0, 3);
                        score = Convert.ToInt16(currentScore) + 100;
                        if (playerNr == 1) { scorecard_Player1_Yahtzee.Content = score.ToString(); }
                        if (playerNr == 2) { scorecard_Player2_Yahtzee.Content = score.ToString(); }
                    }

                    // Score
                    score = Convert.ToInt16(scorecard.Content);
                    continueMove = true;
                }

                // Continu move
                if (continueMove)
                {
                    // Determine 'sumPlayer'
                    int sumPlayer = new int();
                    if (playerNr == 1) { sumPlayer = sumPlayer1; }
                    if (playerNr == 2) { sumPlayer = sumPlayer2; }

                    // Determine 'bonusPlayer'
                    bool bonusPlayer = new bool();
                    if (playerNr == 1) { bonusPlayer = bonusPlayer1; }
                    if (playerNr == 2) { bonusPlayer = bonusPlayer2; }

                    // Determine 'totalPlayer'
                    int totalPlayer = new int();
                    if (playerNr == 1) { totalPlayer = totalPlayer1; }
                    if (playerNr == 2) { totalPlayer = totalPlayer2; }

                    // If scorecard is one of the labels in the upperbox, add score to 'Sum'
                    List<Label> upperBoxLabels = scorecardLabels.GetRange(0, 6);

                    if (upperBoxLabels.Contains(scorecard))
                    {
                        sumPlayer += score;
                        if (playerNr == 1) { ShowSumOrTotal(scorecard_Player1_Sum, sumPlayer); }
                        if (playerNr == 2) { ShowSumOrTotal(scorecard_Player2_Sum, sumPlayer); }
                    }

                    // If 'Sum' is >= 63 point, give the player bonus points, 
                    // add these to the total score and set the bonus check bool to true
                    if (sumPlayer >= 63 && bonusPlayer == false)
                    {
                        if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Bonus, bonuspoints); }
                        if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Bonus, bonuspoints); }

                        totalPlayer += bonuspoints;
                        bonusPlayer = true;
                    }

                    // Check if bonus can still be reached, if not give zero bonuspoints
                    if (sumPlayer < 63)
                    {
                        int needed = 63 - sumPlayer;
                        int possible = 0;

                        for (int i = 0; i < upperBoxLabels.Count; i++)
                        {
                            if (selectedMoves[i] == false)
                            {
                                possible += 5 * (i + 1);
                            }
                        }

                        if (needed > possible)
                        {
                            bonuspoints = 0;
                            if (playerNr == 1) { ShowScoreCardContent(scorecard_Player1_Bonus, bonuspoints); }
                            if (playerNr == 2) { ShowScoreCardContent(scorecard_Player2_Bonus, bonuspoints); }

                            totalPlayer += bonuspoints;
                            bonusPlayer = false;
                        }
                    }

                    // Add added score to total score
                    if (!extraYahtzee)
                    {
                        totalPlayer += score;
                    }
                    else
                    {
                        int extraScore = 100;
                        totalPlayer += score + extraScore;
                    }

                    // Show new total score on scorecard
                    if (playerNr == 1) { ShowSumOrTotal(scorecard_Player1_TotalScore, totalPlayer); }
                    if (playerNr == 2) { ShowSumOrTotal(scorecard_Player2_TotalScore, totalPlayer); }

                    // Save values
                    if (playerNr == 1)
                    {
                        sumPlayer1 = sumPlayer;
                        bonusPlayer1 = bonusPlayer;
                        totalPlayer1 = totalPlayer;
                    }

                    if (playerNr == 2)
                    {
                        sumPlayer2 = sumPlayer;
                        bonusPlayer2 = bonusPlayer;
                        totalPlayer2 = totalPlayer;
                    }

                    // Saves selected moves to list corresponding to current player number
                    if (playerNr == 1) { selectedMoves_Player1 = selectedMoves; }
                    if (playerNr == 2) { selectedMoves_Player2 = selectedMoves; }

                    // Clear possible scores of all the moves that remain unselected
                    ClearUnselectedMoves(playerNr);

                    // Check if game over is true
                    byte numOfMovesSelected = 0;
                    byte totalMoves;

                    if (gametype != Gametype.Alone)
                    {
                        totalMoves = 26;
                    }
                    else
                    {
                        totalMoves = 13;
                    }

                    for (byte i = 0; i < 13; i++)
                    {
                        if (selectedMoves_Player1[i] == true)
                        {
                            numOfMovesSelected++;
                        }

                        if (selectedMoves_Player2[i] == true)
                        {
                            numOfMovesSelected++;
                        }
                    }

                    // If gameover
                    if (numOfMovesSelected == totalMoves)
                    {
                        // Remove the roll dice buttons
                        button_rollDice_player1.Visibility = Visibility.Collapsed;
                        button_rollDice_player2.Visibility = Visibility.Collapsed;

                        // Follow game over procedure
                        GameOver();
                    }

                    // If not gameover
                    if (numOfMovesSelected != totalMoves)
                    {
                        // Change turn
                        ChangeTurn();
                    }
                }
            }
        }

        // GAME OVER
        private void GameOver()
        {
            int scorePlayer1 = Convert.ToInt16(scorecard_Player1_TotalScore.Content.ToString());
          
            if (gametype == Gametype.AgainstEachOther)
            {
                int scorePlayer2 = Convert.ToInt16(scorecard_Player2_TotalScore.Content.ToString());

                if (scorePlayer1 > scorePlayer2)
                {
                    GiveInfo(textBlock_info,
                             $"{namePlayer1} wins!");
                }
                else if (scorePlayer1 < scorePlayer2)
                {
                    GiveInfo(textBlock_info,
                             $"{namePlayer2} wins!");
                }
                else
                {
                    // Score is even. Check the Yahtzee score
                    scorePlayer1 = Convert.ToInt16(scorecard_Player1_Yahtzee.Content.ToString());
                    scorePlayer2 = Convert.ToInt16(scorecard_Player2_Yahtzee.Content.ToString());

                    if (scorePlayer1 > scorePlayer2)
                    {
                        GiveInfo(textBlock_info,
                                 $"The score is even, but {namePlayer1} wins because {namePlayer1} has thrown more Yahtzees!");
                    }
                    else if (scorePlayer1 < scorePlayer2)
                    {
                        GiveInfo(textBlock_info,
                                 $"The score is even, but {namePlayer2} wins because {namePlayer2} has thrown more Yahtzees!");
                    }
                    else
                    {
                        GiveInfo(textBlock_info,
                                 $"The score is even! " 
                                 + Environment.NewLine
                                 + $"You both scored {scorePlayer1} points.");
                    }
                }    
            }
            else
            {
                GiveInfo(textBlock_info,
                         $"The game is over now." 
                         + Environment.NewLine
                         + $"You've scored {scorePlayer1} points!");
            }

            // Start a new game?
            label_startNewGame.Content = "Start a new game";
            label_startNewGame.Visibility = Visibility.Visible;
        }

        private void ResetToStartScreen()
        {
            // Reset numbers/bools
            sumPlayer1 = 0; 
            bonusPlayer1 = false; 
            totalPlayer1 = 0; 
            numOfDiceSelected = 0;
            numOfDiceToThrow = 5;
            throwsLeft = 3;

            // Clear list
            numOfPipsSelectedDice.Clear();

            // Set selected moves to false and clear scorecard
            for (byte i = 0; i < selectedMoves_Player1.Count; i++)
            {
                selectedMoves_Player1[i] = false;
            }

            ClearUnselectedMoves(1);

            // Clear sum, bonus and total score cells on scorecard
            scorecard_Player1_Sum.Content = "";
            scorecard_Player1_Bonus.Content = "";
            scorecard_Player1_TotalScore.Content = "";

            // Clear name
            namePlayer1 = "";

            // If gametype is not 'Alone', clear everything from player 2
            if (gametype != Gametype.Alone)
            {
                sumPlayer2 = 0;
                bonusPlayer2 = false;
                totalPlayer2 = 0;

                for (byte i = 0; i < selectedMoves_Player2.Count; i++)
                {
                    selectedMoves_Player2[i] = false;
                }

                ClearUnselectedMoves(2);

                scorecard_Player2_Sum.Content = "";
                scorecard_Player2_Bonus.Content = "";
                scorecard_Player2_TotalScore.Content = "";

                namePlayer2 = "";
            }   

            // Set screen to choose new game
            SetStartScreen();
            ThrowDice(5);
            GiveInfo(textBlock_info, "");

            // Reset name textbox
            textBox_namePlayer.Text = ""; 
        }

        // BUTTON 'Start new game'
        private void Label_startNewGame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ResetToStartScreen();
        }

        // BUTTON to set number of throws left
        // COMMENT: For testing purposes this button, together with the textbox tb_throwsleft can be used to set the number of throws left.
        // To do this these control first have to be made visible.To find the controls the 'Document Outline' in the MainWindow screen can be used.
        private void Btn_throwsleft_Click(object sender, RoutedEventArgs e)
        {
            throwsLeft = Convert.ToByte(tb_throwsleft.Text);
        }
    }
}