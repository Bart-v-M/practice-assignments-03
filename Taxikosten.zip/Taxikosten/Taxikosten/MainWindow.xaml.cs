﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Taxikosten
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            textBox_specification_costs.Visibility = Visibility.Collapsed;
            textBox_specification_costs_amounts.Visibility = Visibility.Collapsed;
        }

        // LOAD LIST OF DAYNUMBERS
        private void LoadListOfDayNumbers(object sender)
        {
            // Declaration of the list
            List<string> listOfdayNumbers = new List<string>();

            // Assignment 1st list item (title)
            listOfdayNumbers.Add("dag");

            // Assignment all days of the month
            for (int i = 1; i <= 31; i++)
            {
                listOfdayNumbers.Add(i.ToString());
            }

            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfdayNumbers;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        // LOAD LIST OF MONTHS
        private void LoadListOfMonths(object sender)
        {
            // Declaration of the list
            List<string> listOfMonths = new List<string>
            { "maand", "januari", "februari", "maart", "april", "mei", "juni",
              "juli", "augustus", "september", "oktober", "november", "december"};

            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfMonths;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        // LOAD LIST OF YEARS
        private void LoadListOfYears(object sender)
        {
            // Declaration of the list
            List<string> listOfYears = new List<string>();

            // Assignment 1st list item (title)
            listOfYears.Add("jaar");

            // Assignment of last 100 years
            int year = DateTime.Now.Year;
            for (int i = year; i >= year - 5; i--)
            {
                listOfYears.Add(i.ToString());
            }
            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfYears;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        // LOAD LIST OF START TIME HOURS
        private void LoadListOfHours(object sender)
        {
            // Declaration of the list
            List<string> listOfStarttimeHours = new List<string>();

            // Assignment 1st list item (title)
            listOfStarttimeHours.Add("uur");

            // Assignment all days of the month
            for (int i = 0; i <= 23; i++)
            {
                if (i >= 0 && i <= 9) { listOfStarttimeHours.Add("0" + i.ToString()); }
                if (i >= 10 && i <= 23) { listOfStarttimeHours.Add(i.ToString()); }
            }

            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfStarttimeHours;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        // LOAD LIST OF START TIME MINUTES
        private void LoadListOfMinutes(object sender)
        {
            // Declaration of the list
            List<string> listOfStarttimeMinutes = new List<string>();

            // Assignment 1st list item (title)
            listOfStarttimeMinutes.Add("min.");

            // Assignment all days of the month
            for (int i = 0; i <= 59; i++)
            {
                if (i >= 0 && i <= 9) { listOfStarttimeMinutes.Add("0" + i.ToString()); }
                if (i >= 10 && i <= 59) { listOfStarttimeMinutes.Add(i.ToString()); }
            }

            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfStarttimeMinutes;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }


        // DETERMINE DATE VALIDITY
        bool inputIsCorrect;
        DateTime date;
        byte hour_start; byte minute_start;
        byte hour_end; byte minute_end;
        int numOfKm;

        private void CheckValidity_inputs()
        {
            // Preset
            inputIsCorrect = true;
            
            // Check if date is valid. 
            // If true, determine birthdate and age. If false, give error message.
            try
            {
                // Determine year
                int year = Convert.ToInt16(comboBox_date_year.Text);

                // Determine month (with selected index number of combobox)
                int month = Convert.ToInt16(comboBox_date_month.SelectedIndex);

                // Determine day
                int day = Convert.ToInt16(comboBox_date_day.Text);

                // Check birthdate
                date = new DateTime(year, month, day);
            }
            catch (Exception)
            {
                // Show message
                MessageBox.Show("De ritdatum is niet of onjuist ingevoerd. Voer een geldige datum in.",
                                     "Geen of onjuiste invoer");

                // Set 'inputIsCorrect' to false
                inputIsCorrect = false;
            }

            if (inputIsCorrect)
            {
                if (comboBox_starttime_hour.SelectedIndex == 0 || comboBox_starttime_minute.SelectedIndex == 0)
                {
                    // Show message
                    MessageBox.Show("Voer de starttijd in.",
                                   "Geen of onjuiste invoer");

                    // Set 'inputIsCorrect' to false
                    inputIsCorrect = false;
                }
            }

            if (inputIsCorrect)
            {
                if (comboBox_endtime_hour.SelectedIndex == 0 || comboBox_endtime_minute.SelectedIndex == 0)
                {
                    // Show message
                    MessageBox.Show("Voer de eindtijd in.",
                                   "Geen of onjuiste invoer");

                    // Set 'inputIsCorrect' to false
                    inputIsCorrect = false;
                }
            }

            if (inputIsCorrect)
            {
                if (textBox_numOfKm.Text == "")
                {
                    // Show message
                    MessageBox.Show("Voer het aantal gereden kilometers in.",
                                   "Geen of onjuiste invoer");

                    // Set 'inputIsCorrect' to false
                    inputIsCorrect = false;
                }
            }

            if (inputIsCorrect)
            {
                if (textBox_numOfKm.Text.Length > 4)
                {
                    // Show message
                    MessageBox.Show("Maximale invoer voor het aantal gereden kilometers is bereikt. Voer maximaal 4 cijfers in.",
                                   "Geen of onjuiste invoer");

                    // Set 'inputIsCorrect' to false
                    inputIsCorrect = false;
                }
            }

            if (inputIsCorrect)
            {
                string text = textBox_numOfKm.Text;
                char[] chars = text.ToCharArray();
                List<char> listOfnumbers = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
                
                foreach (char c in chars)
                {
                    if (!listOfnumbers.Contains(c) && inputIsCorrect == true)
                    {
                        // Show message
                        MessageBox.Show("Voor het aantal gereden kilometers is alleen de invoer van cijfers toegestaan.",
                                       "Geen of onjuiste invoer");

                        // Set 'inputIsCorrect' to false
                        inputIsCorrect = false;
                    }
                }
            }

            if (inputIsCorrect)
            {
               
            }
        }


        // CALCULATE
        private void CalculateAndShow()
        {
            // Clear focus textBox_numOfKm
            ClearFocus();

            // Variables
            bool weekendMarkup = false;
            double tariff_day = 0.25;
            double tariff_night = 0.45;
            double tariff_km = 1.00;
            double markup_weekend = 1.15;
            int numOfMinutes_day = 0;
            int numOfMinutes_night = 0;
            double price_minutes_day = 0;
            double price_minutes_night = 0;
            double price_minutes = 0;
            double price_km = 0;
            double price_total = 0;

            // Set cost to zero
            textBlock_cost_amount.Text = price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"));

            // Remove cost specification boxes (earlier given) from screen
            textBox_specification_costs.Visibility = Visibility.Collapsed;
            textBox_specification_costs_amounts.Visibility = Visibility.Collapsed;

            // Check date and time validity
            CheckValidity_inputs();

            // Assign given input values to variables
            if (inputIsCorrect)
            {
                hour_start = Convert.ToByte(comboBox_starttime_hour.SelectedValue);
                minute_start = Convert.ToByte(comboBox_starttime_minute.SelectedValue);
                hour_end = Convert.ToByte(comboBox_endtime_hour.SelectedValue);
                minute_end = Convert.ToByte(comboBox_endtime_minute.SelectedValue);
                numOfKm = Convert.ToInt16(textBox_numOfKm.Text);
            }

            // Determine number of minutes during day and/or night, and the price to pay for the number of minutes
            if (inputIsCorrect)
            {
                // Only during day time
                if (hour_start >= 8 && hour_start < 18
                    && hour_end >= 8 && hour_end < 18)
                {
                    numOfMinutes_day = ((hour_end - hour_start) * 60) + (minute_end - minute_start);
                }

                // Only during night time (before midnight)
                if (hour_start >= 18 && hour_start <= 23
                    && hour_end >= 18 && hour_end <= 23)
                {
                    numOfMinutes_night = ((hour_end - hour_start) * 60) + (minute_end - minute_start);
                }

                // Only during night time (after midnight)
                if (hour_start >= 0 && hour_start < 8
                    && hour_end >= 0 && hour_end < 8)
                {
                    numOfMinutes_night = ((hour_end - hour_start) * 60) + (minute_end - minute_start);
                }

                // Only during night time (start during night time before midnight, end during night time after midnight, before morning)
                if (hour_start >= 18 && hour_start <= 23
                    && hour_end >= 0 && hour_end < 8)
                {
                    numOfMinutes_night = ((24 - hour_start) * 60) + (hour_end * 60) + minute_end;
                }

                // Start during day time, end during night time (before midnight)
                if (hour_start >= 8 && hour_start < 18
                    && hour_end >= 18 && hour_end <= 23)
                {
                    numOfMinutes_day = ((18 - hour_start) * 60) - minute_start;
                    numOfMinutes_night = ((hour_end - 18) * 60) + minute_end;
                }

                // Start during day time, end during night time (after midnight, before morning)
                if (hour_start >= 8 && hour_start < 18
                    && hour_end >= 0 && hour_end < 8)
                {
                    numOfMinutes_day = ((18 - hour_start) * 60) - minute_start;
                    numOfMinutes_night = ((24 - 18) * 60) + (hour_end * 60) + minute_end;
                }

                // Start during night time (after midnight), end during day time (before evening)
                if (hour_start >= 0 && hour_start < 8
                    && hour_end >= 8 && hour_end < 18)
                {
                    numOfMinutes_night = ((8 - hour_start) * 60) - minute_start;
                    numOfMinutes_day = ((hour_end - 8) * 60) + minute_end;
                }

                // ONLY for testing purposes
                //MessageBox.Show(numOfMinutes_day.ToString() + " " + numOfMinutes_night.ToString());

                // Check if maximum number of minutes is reached
                if ((numOfMinutes_day + numOfMinutes_night > 480)
                    || numOfMinutes_day + numOfMinutes_night == 0)
                {
                    // Show message
                    MessageBox.Show("Alleen taxiritten tot maximaal 8 uur zijn mogelijk.",
                                   "Maximale ritduur bereikt");

                    // Set price in screen to zero
                    price_total = 0;
                    textBlock_cost_amount.Text = price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"));

                    // Set 'inputIsCorrect' to false
                    inputIsCorrect = false;
                }
            }

            if (inputIsCorrect)
            {
                // Determine rate type (if week rate is false, then there is a weekend rate)
                if ((date.DayOfWeek == DayOfWeek.Friday && hour_start >= 22 && hour_start <= 23)
                    || date.DayOfWeek == DayOfWeek.Saturday
                    || date.DayOfWeek == DayOfWeek.Sunday
                    || (date.DayOfWeek == DayOfWeek.Monday && hour_start >= 0 && hour_start < 7))
                { weekendMarkup = true; }
                else { weekendMarkup = false; }

                // Determine the price to pay for the minutes driven
                price_minutes_day = numOfMinutes_day * tariff_day;
                price_minutes_night = numOfMinutes_night * tariff_night;
                price_minutes = price_minutes_day + price_minutes_night;

                // Determine the price to pay for the kilometers driven
                price_km = numOfKm * tariff_km;

                // Determine the total price to pay for the taxi drive
                price_total = price_minutes + price_km;
                if (weekendMarkup) { price_total *= markup_weekend; }
                else { } // Ignore

                textBlock_cost_amount.Text = price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"));

                // Show specification of costs:
                // Outside the weekend, day hours only
                if (weekendMarkup == false && numOfMinutes_day != 0 && numOfMinutes_night == 0)
                {
                    textBox_specification_costs.Text =
                    $"Aantal gereden kilometers x km-tarief = {numOfKm} x {tariff_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"Aantal minuten x dagtarief = {numOfMinutes_day} x {tariff_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"Totaal";

                    textBox_specification_costs_amounts.Text =
                    $"{price_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"{price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}";
                }

                // Outside the weekend, night hours only
                if (weekendMarkup == false && numOfMinutes_day == 0 && numOfMinutes_night != 0)
                {
                    textBox_specification_costs.Text =
                    $"Aantal gereden kilometers x km-tarief = {numOfKm} x {tariff_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"Aantal minuten x avond-/nachttarief = {numOfMinutes_night} x {tariff_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"Totaal";

                    textBox_specification_costs_amounts.Text =
                    $"{price_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"{price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}";
                }

                // Outside the weekend, day and night hours
                if (weekendMarkup == false && numOfMinutes_day != 0 && numOfMinutes_night != 0)
                {
                    textBox_specification_costs.Text =
                     $"Aantal kilometers x km-tarief = {numOfKm} x {tariff_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                     + $"Aantal minuten x dagtarief = {numOfMinutes_day} x {tariff_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                     + $"Aantal minuten x avond-/nachttarief = {numOfMinutes_night} x {tariff_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                     + Environment.NewLine
                     + $"Totaal";

                    textBox_specification_costs_amounts.Text =
                    $"{price_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"{price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}";
                }

                // In the weekend, day hours only
                if (weekendMarkup == true && numOfMinutes_day != 0 && numOfMinutes_night == 0)
                {
                    textBox_specification_costs.Text =
                    $"Aantal gereden kilometers x km-tarief = {numOfKm} x {tariff_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"Aantal minuten x dagtarief = {numOfMinutes_day} x {tariff_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"Weekendtoeslag (+{(markup_weekend - 1) * 100}%)"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"Totaal";

                    textBox_specification_costs_amounts.Text =
                    $"{price_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{((markup_weekend - 1) * (price_total / markup_weekend)).ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"{price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}";
                }

                // In the weekend, night hours only
                if (weekendMarkup == true && numOfMinutes_day == 0 && numOfMinutes_night != 0)
                {
                    textBox_specification_costs.Text =
                    $"Aantal gereden kilometers x km-tarief = {numOfKm} x {tariff_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"Aantal minuten x avond-/nachttarief = {numOfMinutes_night} x {tariff_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                    + $"Weekendtoeslag (+{(markup_weekend - 1) * 100}%)"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"Totaal";

                    textBox_specification_costs_amounts.Text =
                    $"{price_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{((markup_weekend - 1) * (price_total / markup_weekend)).ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"{price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}";
                }

                // In the weekend, day and night hours
                if (weekendMarkup == true && numOfMinutes_day != 0 && numOfMinutes_night != 0)
                {
                    textBox_specification_costs.Text =
                     $"Aantal gereden kilometers x km-tarief = {numOfKm} x {tariff_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                     + $"Aantal minuten x dagtarief = {numOfMinutes_day} x {tariff_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                     + $"Aantal minuten x avond-/nachttarief = {numOfMinutes_night} x {tariff_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                     + Environment.NewLine
                     + $"Weekendtoeslag (+{(markup_weekend - 1) * 100}%)"
                     + Environment.NewLine
                     + Environment.NewLine
                     + $"Totaal";

                    textBox_specification_costs_amounts.Text =
                    $"{price_km.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_day.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{price_minutes_night.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + $"{((markup_weekend - 1) * (price_total / markup_weekend)).ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}"
                    + Environment.NewLine
                    + Environment.NewLine
                    + $"{price_total.ToString("C", CultureInfo.GetCultureInfo("nl-NL"))}";
                }

                if (checkBox_showSpecification.IsChecked == true)
                {
                    // Make textboxes visible on screen
                    textBox_specification_costs.Visibility = Visibility.Visible;
                    textBox_specification_costs_amounts.Visibility = Visibility.Visible;
                }
                else
                {
                    // Ignore
                }
            }
        }


        // CALCULATE BUTTON MOUSEDOWN
        private void Label_calculateButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            CalculateAndShow();
        }


        // LOAD COMBOBOXES
        private void ComboBox_date_day_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfDayNumbers(sender);
        }

        private void ComboBox_date_month_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfMonths(sender);
        }

        private void ComboBox_date_year_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfYears(sender);
        }

        private void ComboBox_starttime_hour_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfHours(sender);
        }

        private void ComboBox_starttime_minute_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfMinutes(sender);
        }

        private void ComboBox_endtime_hour_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfHours(sender);
        }

        private void ComboBox_endtime_minute_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfMinutes(sender);
        }


        // CHANGE FOREGROUND COLOR COMBOBOX AT SELECTION CHANGE
        private void ChangeForeGroundColorComboBoxAtSelectionChange(object sender)
        {
            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Change foreground color
            if (comboBox.SelectedIndex != 0)
            {
                comboBox.Foreground = new SolidColorBrush(Colors.Black);
            }
            else
            {
                comboBox.Foreground = new SolidColorBrush(Colors.DimGray);
            }
        }

        private void ComboBox_date_day_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_date_month_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_date_year_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_starttime_hour_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_starttime_minute_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender); 
        }

        private void ComboBox_endtime_hour_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_endtime_minute_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }


        // CHANGE FOREGROUND COLOR COMBOBOXES AT MOUSE CAPTURE
        private void ChangeForeGroundColorComboBoxAtMouseCapture(object sender, Color color)
        {
            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Change foreground color
            comboBox.Foreground = new SolidColorBrush(color);
        }

        private void ComboBox_date_day_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }

        private void ComboBox_date_month_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }

        private void ComboBox_date_year_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }

        private void ComboBox_starttime_hour_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }

        private void ComboBox_starttime_minute_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }

        private void ComboBox_endtime_hour_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }

        private void ComboBox_endtime_minute_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
            ClearFocus();
        }


        // CHANGE FOREGROUND COLOR COMBOBOXES AT LOST MOUSE CAPTURE
        private void ChangeForeGroundColorComboBoxAtLostMouseCapture(object sender, Color color)
        {
            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Change foreground color
            if (comboBox.SelectedIndex == 0)
            {
                comboBox.Foreground = new SolidColorBrush(color);
            }
        }

        private void ComboBox_date_day_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_date_month_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_date_year_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_starttime_hour_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_starttime_minute_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_endtime_hour_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_endtime_minute_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }


        // CHANGE CARETBRUSH COLOR
        private void ChangeCaretBrushColor(TextBox textBox, Color color)
        {
            textBox.CaretBrush = new SolidColorBrush(color);
        }

        private void TextBox_numOfKm_GotFocus(object sender, RoutedEventArgs e)
        {
            ChangeCaretBrushColor(textBox_numOfKm, Colors.Black);
        }

        private void TextBox_numOfKm_LostFocus(object sender, RoutedEventArgs e)
        {
            ChangeCaretBrushColor(textBox_numOfKm, Colors.White); 
        }

        // SET TEXTBOX FOCUS TO FALSE
        private void ClearFocus()
        {
            Keyboard.ClearFocus();
        }

        // CHECKBOX SHOW SPECIFICATION
        bool show;
        private void CheckBox_showSpecification_Click(object sender, RoutedEventArgs e)
        {
            if (checkBox_showSpecification.IsChecked == false) { show = false; }
            else { show = true; }

            if (!show)
            {
                textBox_specification_costs.Visibility = Visibility.Collapsed;
                textBox_specification_costs_amounts.Visibility = Visibility.Collapsed;
            }

            if (show && textBlock_cost_amount.Text != "€ 0,00")
            {
                textBox_specification_costs.Visibility = Visibility.Visible;
                textBox_specification_costs_amounts.Visibility = Visibility.Visible;
            }
            else
            {
                // Ignore
            }
        }
    }
}
