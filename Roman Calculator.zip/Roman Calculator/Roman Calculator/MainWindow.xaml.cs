﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Roman_Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CreateReplacementLists();
            ScriptRomanMaster("start");
        }

        // UPDATE NUMBERS AND DISPLAYS
        string onDisplay_Roman;
        string onDisplay_Arabic = string.Empty;
        string numberHit_Roman;
        string numberHit_Arabic;
        double number_Arabic;
       
        private void UpdateDisplay_Roman(string number)
        {
            // Show number on display
            display_Roman.Content = number;
        }

        private void UpdateDisplay_Arabic(string number)
        {
            // Make array and list of chars
            char[] nums = number.ToCharArray();
            List<char> numbers = nums.ToList();

            // Check if list contains a dot and if true, split the number string into two parts
            string[] parts;
            if (numbers.Contains('.'))
            {
                parts = number.Split('.');
                parts[0] = Convert.ToDouble(parts[0]).ToString("N0"); // add commas, as a thousands separator
                number = parts[0] + '.' + parts[1]; // add dot, to bring the two parts together again
            }
            else { number = Convert.ToDouble(number).ToString("N0"); } // add commas, as a thousands separator
            // COMMENT: The separators for thousands and decimals for this program are given in English/American style.
            // If wanted this could ofcourse be changed very easily.  

            // Show number on display
            display_Arabic.Content = number;
        }

        private void UpdateNumber_Roman(string numberHit_Roman)
        {
            onDisplay_Roman += numberHit_Roman;
        }

        private void UpdateNumber_Arabic(string numberHit_Arabic)
        {
            if (onDisplay_Arabic == "0") { onDisplay_Arabic = string.Empty; } // clear display string, if 0
            if (onDisplay_Arabic == string.Empty) { number_Arabic = 0; } // make sure the number is 0, if display is empty
            // DO NOT REMOVE STATEMENTS ABOVE
          
            if (onDisplay_Arabic != string.Empty) { number_Arabic = Convert.ToDouble(onDisplay_Arabic); }
            else { number_Arabic = 0; }

            double numberHit = Convert.ToDouble(numberHit_Arabic);
            number_Arabic += numberHit;
            number_Arabic = Math.Round(number_Arabic, 0);
            onDisplay_Arabic = number_Arabic.ToString();            
        }

        private void UpdateNumbersAndDisplays_hitButton(string numberHit_R, string numberHit_A)
        {
            numberHit_Roman = numberHit_R;
            numberHit_Arabic = numberHit_A;

            // Clear display strings if previous button was not a number
            if (previousButton_operation || previousButton_equals)
            {
                onDisplay_Roman = string.Empty;
                onDisplay_Arabic = string.Empty;    
            }

            UpdateNumber_Roman(numberHit_Roman); UpdateDisplay_Roman(onDisplay_Roman);
            UpdateNumber_Arabic(numberHit_Arabic); UpdateDisplay_Arabic(onDisplay_Arabic); 
        }


        // DISABLE AND ENABLE BUTTONS
        bool buttons1digit_enabled = true;
        bool buttons2digit_enabled = true;
        bool buttons3digit_enabled = true;
        bool buttons4digit_enabled = true;

        private void DisableButtons(byte numOfDigits)
        {
            switch (numOfDigits)
            {
                case 1: 
                    buttons1digit_enabled = false;
                    buttons2digit_enabled = false;
                    buttons3digit_enabled = false;
                    buttons4digit_enabled = false;
                    ChangeForegroundColorButtons(numOfDigits, true);
                    break;

                case 2:
                    buttons2digit_enabled = false;
                    buttons3digit_enabled = false;
                    buttons4digit_enabled = false;
                    ChangeForegroundColorButtons(numOfDigits, true);
                    break;

                case 3:
                    buttons3digit_enabled = false;
                    buttons4digit_enabled = false;
                    ChangeForegroundColorButtons(numOfDigits, true);
                    break;

                case 4:
                    buttons4digit_enabled = false;
                    ChangeForegroundColorButtons(numOfDigits, true);
                    break;
            }
        }

        private void EnableButtons()
        {
            buttons1digit_enabled = true; ChangeForegroundColorButtons(1, false);
            buttons2digit_enabled = true; ChangeForegroundColorButtons(2, false);
            buttons3digit_enabled = true; ChangeForegroundColorButtons(3, false);
            buttons4digit_enabled = true; ChangeForegroundColorButtons(4, false);
        }


        // CHANGE BUTTON FOREGROUND COLOR WHEN DISABLED
        private void ChangeForegroundColorButtons(byte numOfDigits, bool disableButton)
        {
            List<Label> buttons1digit = new List<Label>()
            {
                button_I_1, button_II_2, button_III_3, button_IV_4, button_V_5,
                button_VI_6, button_VII_7, button_VIII_8, button_IX_9
            };

            List<Label> buttons2digit = new List<Label>()
            {
                button_X_10, button_XX_20, button_XXX_30, button_XL_40, button_L_50,
                button_LX_60, button_LXX_70, button_LXXX_80, button_XC_90
            };

            List<Label> buttons3digit = new List<Label>()
            {
                button_C_100, button_CC_200, button_CCC_300, button_CD_400, button_D_500,
                button_DC_600, button_DCC_700, button_DCCC_800, button_CM_900
            };

            List<Label> buttons4digit = new List<Label>()
            {
                button_M_1000, button_MM_2000, button_MMM_3000
            };

            switch (numOfDigits)
            {
                case 1:
                    foreach (Label label in buttons1digit) { ChangeForeGroundColor(label, disableButton); }
                    foreach (Label label in buttons2digit) { ChangeForeGroundColor(label, disableButton); }
                    foreach (Label label in buttons3digit) { ChangeForeGroundColor(label, disableButton); }
                    foreach (Label label in buttons4digit) { ChangeForeGroundColor(label, disableButton); }
                    break;

                case 2:
                    foreach (Label label in buttons2digit) { ChangeForeGroundColor(label, disableButton); }
                    foreach (Label label in buttons3digit) { ChangeForeGroundColor(label, disableButton); }
                    foreach (Label label in buttons4digit) { ChangeForeGroundColor(label, disableButton); }
                    break;

                case 3:
                    foreach (Label label in buttons3digit) { ChangeForeGroundColor(label, disableButton); }
                    foreach (Label label in buttons4digit) { ChangeForeGroundColor(label, disableButton); }
                    break;

                case 4:
                    foreach (Label label in buttons4digit) { ChangeForeGroundColor(label, disableButton); }
                    break;
            }
        }

        private void ChangeForeGroundColor(Label label, bool disableButton)
        {
            if (disableButton) { label.Foreground = new SolidColorBrush(Colors.Silver); }
            else { label.Foreground = new SolidColorBrush(Colors.Black); }
        }

     
        // FOUR DIGIT NUMBER BUTTONS

        // M / 1000
        private void Button_M_1000_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons4digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("M", "1000");
                DisableButtons(4);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }       
        }

        // MM / 2000
        private void Button_MM_2000_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons4digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("MM", "2000");
                DisableButtons(4);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }      
        }

        // MMM / 3000
        private void Button_MMM_3000_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons4digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("MMM", "3000");
                DisableButtons(4);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }     
        }


        // THREE DIGIT NUMBER BUTTONS

        // C / 100
        private void Button_C_100_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("C", "100");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }  
        }

        // CC / 200
        private void Button_CC_200_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("CC", "200");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }   
        }

        // CCC / 300
        private void Button_CCC_300_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("CCC", "300");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }       
        }

        // CD / 400
        private void Button_CD_400_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("CD", "400");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }       
        }

        // D / 500
        private void Button_D_500_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("D", "500");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }  
        }

        // DC / 600
        private void Button_DC_600_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("DC", "600");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }   
        }

        // DCC / 700
        private void Button_DCC_700_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("DCC", "700");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }      
        }

        // DCCC / 800
        private void Button_DCCC_800_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("DCCC", "800");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }    
        }

        // CM / 900
        private void Button_CM_900_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons3digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("CM", "900");
                DisableButtons(3);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }            
        }


        // TWO DIGIT NUMBER BUTTONS

        // X / 10
        private void Button_X_10_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("X", "10");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }      
        }

        // XX / 20
        private void Button_XX_20_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("XX", "20");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }     
        }

        // XXX / 30
        private void Button_XXX_30_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("XXX", "30");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }      
        }

        // XL / 40
        private void Button_XL_40_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("XL", "40");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }    
        }

        // L / 50
        private void Button_L_50_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("L", "50");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }     
        }

        // LX / 60
        private void Button_LX_60_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("LX", "60");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }     
        }

        // LXX / 70
        private void Button_LXX_70_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("LXX", "70");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            } 
        }

        // LXXX / 80
        private void Button_LXXX_80_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("LXXX", "80");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }  
        }

        // XC / 90
        private void Button_XC_90_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons2digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("XC", "90");
                DisableButtons(2);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }   
        }


        // SINGLE DIGIT BUTTONS

        // I / 1
        private void Button_I_1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("I", "1");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }   
        }

        // II / 2
        private void Button_II_2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("II", "2");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }       
        }

        // III / 3
        private void Button_III_3_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("III", "3");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }
        }
           

        // IV / 4
        private void Button_IV_4_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("IV", "4");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }        
        }

        // V / 5
        private void Button_V_5_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("V", "5");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }    
        }

        // VI / 6
        private void Button_VI_6_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("VI", "6");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }   
        }

        // VII / 7
        private void Button_VII_7_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("VII", "7");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }        
        }

        // VIII / 8
        private void Button_VIII_8_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("VIII", "8");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }
        }

        // IX / 9
        private void Button_IX_9_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (buttons1digit_enabled)
            {
                UpdateNumbersAndDisplays_hitButton("IX", "9");
                DisableButtons(1);
                ScriptRomanMaster(string.Empty);
                UpdateStatus("number");
            }    
        }


        // OPERATION BUTTONS

        // PLUS
        private void Button_plus_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Do operation
            Operation();
           
            // Set operation to plus (IMPORTANT: don't change this setting before 'Operation()' is executed)
            operation = "+";
        }

        // MINUS
        private void Button_minus_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Do operation
            Operation();

            // Set operation to minus (IMPORTANT: don't change this setting before 'Operation()' is executed)
            operation = "−";
        }

        // MULTIPLY
        private void Button_multiply_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Do operation
            Operation();

            // Set operation to multiply (IMPORTANT: don't change this setting before 'Operation()' is executed)
            operation = "×";
        }

        // DIVIDE
        private void Button_divide_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Do operation
            Operation();

            // Set operation to divide (IMPORTANT: don't change this setting before 'Operation()' is executed)
            operation = "÷";
        }

        // OPERATIONS METHOD
        double value1;
        string operation = string.Empty;
        double value2;
        double result;

        private void Operation()
        {
            if (operation == string.Empty && previousButton_number)
            {
                // Set value 1
                value1 = Convert.ToDouble(onDisplay_Arabic);

                // Set script Roman master
                ScriptRomanMaster(string.Empty);
            }

            if (operation != string.Empty && previousButton_number) 
            {
                // Set value 2
                value2 = Convert.ToDouble(onDisplay_Arabic);

                // Select and do operation
                switch (operation)
                {
                    case "+":
                        result = value1 + value2;
                        break;

                    case "−":
                        result = value1 - value2;
                        break;

                    case "×":
                        result = value1 * value2;
                        break;

                    case "÷":
                        result = value1 / value2;
                        break;
                }

                // Update Arabic display with calculated result
                onDisplay_Arabic = result.ToString();
                UpdateDisplay_Arabic(onDisplay_Arabic);

                // Set value 1 to result
                value1 = result;

                // Clear current Roman number, for making a new number     
                onDisplay_Roman = string.Empty;
                UpdateDisplay_Roman(onDisplay_Roman);

                // Message from Roman Master
                ScriptRomanMaster("number generated");

                // Convert Arabic to Roman and show on display
                ConvertArabicToRoman(result);
            }

            if (previousButton_equals)
            {
                // Set script Roman master
                ScriptRomanMaster(string.Empty);
            }

            // Enable all buttons again, for entering a new number
            EnableButtons();
             
            // Status update
            UpdateStatus("operation");
        }


        // EQUALS OPERATION
        private void Button_equals_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (operation != string.Empty)
            {
                // Set value 2
                value2 = Convert.ToDouble(onDisplay_Arabic);

                // Select and do operation
                switch (operation)
                {
                    case "+":
                        result = value1 + value2;
                        break;

                    case "−":
                        result = value1 - value2;
                        break;

                    case "×":
                        result = value1 * value2;
                        break;

                    case "÷":
                        result = value1 / value2;
                        break;
                }

                // Update Arabic display with calculated result
                onDisplay_Arabic = result.ToString();
                UpdateDisplay_Arabic(onDisplay_Arabic);

                // Set value 1 to result
                value1 = result;

                // Clear current Roman number, for making a new number 
                onDisplay_Roman = string.Empty;
                UpdateDisplay_Roman(onDisplay_Roman);

                // Message from Roman Master
                ScriptRomanMaster("number generated");

                // Convert Arabic to Roman and show on display
                ConvertArabicToRoman(result);

                // Enable all buttons again, for entering a new number
                EnableButtons();
            }

            // Status update
            UpdateStatus("equals");
        }


        // CONVERT ARABIC NUMBER OUTPUT TO ROMAN NUMERALS
        byte numOfDigits;
        byte[] numberArray;

        // Bools to keep track of the script needed from the Roman Master
        bool script1_largeNumber;
        bool script2_largeNumber;
        bool script3_largeNumber;

        // Convert Arabic to Roman
        private void ConvertArabicToRoman(double number)
        {
            // Reset bool for script
            script1_largeNumber = false;
            script2_largeNumber = false;
            script3_largeNumber = false;
            
            // Exception: number < 0
            if (number < 0)
            { UpdateDisplay_Roman(string.Empty); ScriptRomanMaster("< 0"); }

            // Exception: number = 0
            if (number == 0)
            { UpdateDisplay_Roman(string.Empty); UpdateDisplay_Roman("nulla"); ScriptRomanMaster("= 0"); }

            // Exception: number > 999999999 (maximum with 9 digits)
            if (number > 999999999)
            { UpdateDisplay_Roman(string.Empty); ScriptRomanMaster("> 999999999"); }

            // Convert if number > 0 && <= 999999999 (999999999 is 1 billion minus 1)
            if (number > 0 && number <= 999999999)
            {
                // Round off 'number'
                number = Math.Round(number, 0);

                // Count number of digits (only those before the dot, because no decimals should be counted)
                string[] parts = onDisplay_Arabic.Split('.');
                numOfDigits = Convert.ToByte(parts[0].Length);

                // Convert number to string, and make array of separate numbers
                string numbers = number.ToString();
                numberArray = new byte[numbers.Length];
                byte counter = 0;

                for (byte i = 0; i < numbers.Length; i++)
                {
                    numberArray[i] = byte.Parse(numbers.Substring(counter, 1)); // 1 is split length
                    counter++;
                }

                // Reverse array (lowest value first, highest value last)
                Array.Reverse(numberArray);

                // Convert digits
                switch (numOfDigits)
                {
                    case 1:

                        ConvertDigit(1);
                        onDisplay_Roman = digit1_Roman;
                        break;


                    case 2:

                        ConvertDigit(1); ConvertDigit(2);
                        onDisplay_Roman = digit2_Roman + digit1_Roman;
                        break;


                    case 3:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3);
                        onDisplay_Roman = digit3_Roman + digit2_Roman + digit1_Roman;
                        break;


                    // COMMENT:
                    // From here the program uses special characters that the Romans used to notate large numbers:  
                    // Special brackets, 'Ⅽ' and 'Ↄ',  are used when a Roman number is larger than MMMCMXCIX (3999) Example: ⅭIVↃ CCCLI = 4351.
                    // Every additional set of brackets 'Ⅽ' and 'Ↄ', multiplies the value again by another 1000. Example: ((II))VC = 2000090

                    case 4:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4);

                        if (number < 4000)
                        { onDisplay_Roman = digit4_Roman + digit3_Roman + digit2_Roman + digit1_Roman; }
                        else
                        {
                            onDisplay_Roman = 'Ⅽ' + digit4_Roman + "Ↄ " + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("Ⅽ and Ↄ");
                            script1_largeNumber = true;
                        }

                        break;


                    case 5:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4); ConvertDigit(5);
                        onDisplay_Roman = 'Ⅽ' + digit5_Roman + digit4_Roman + "Ↄ " + digit3_Roman + digit2_Roman + digit1_Roman;
                        ScriptRomanMaster("Ⅽ and Ↄ");
                        script1_largeNumber = true;
                        break;


                    case 6:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4); ConvertDigit(5); ConvertDigit(6);
                        onDisplay_Roman = 'Ⅽ' + digit6_Roman + digit5_Roman + digit4_Roman + "Ↄ " + digit3_Roman + digit2_Roman + digit1_Roman;
                        ScriptRomanMaster("Ⅽ and Ↄ");
                        script1_largeNumber = true;
                        break;


                    case 7:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4); ConvertDigit(5); ConvertDigit(6); ConvertDigit(7);

                        if ((digit6_Roman == "" && digit5_Roman == "" && digit4_Roman == "")
                            || digit4_Roman == "M" || digit4_Roman == "MM" || digit4_Roman == "MMM")
                        {
                            onDisplay_Roman = "ⅭⅭ" + digit7_Roman + "ↃↃ " + digit6_Roman + digit5_Roman + digit4_Roman 
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("ⅭⅭ and ↃↃ");
                            script2_largeNumber = true;
                        }
                        else
                        {
                            onDisplay_Roman = "ⅭⅭ" + digit7_Roman + "ↃↃ " + 'Ⅽ' + digit6_Roman + digit5_Roman + digit4_Roman + "Ↄ "
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("Ⅽ and Ↄ, and ⅭⅭ and ↃↃ");
                            script3_largeNumber = true;
                        }

                        break;


                    case 8:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4); ConvertDigit(5); ConvertDigit(6); ConvertDigit(7);
                        ConvertDigit(8);

                        if ((digit6_Roman == "" && digit5_Roman == "" && digit4_Roman == "")
                             || digit4_Roman == "M" || digit4_Roman == "MM" || digit4_Roman == "MMM")
                        {
                            onDisplay_Roman = "ⅭⅭ" + digit8_Roman + digit7_Roman + "ↃↃ " + digit6_Roman + digit5_Roman + digit4_Roman
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("ⅭⅭ and ↃↃ");
                            script2_largeNumber = true;
                        }
                        else
                        {
                            onDisplay_Roman = "ⅭⅭ" + digit8_Roman + digit7_Roman + "ↃↃ " + 'Ⅽ' + digit6_Roman + digit5_Roman + digit4_Roman + "Ↄ "
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("Ⅽ and Ↄ, and ⅭⅭ and ↃↃ");
                            script3_largeNumber = true;
                        }

                        break;


                    case 9:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4); ConvertDigit(5);
                        ConvertDigit(6); ConvertDigit(7); ConvertDigit(8); ConvertDigit(9);

                        if ((digit6_Roman == "" && digit5_Roman == "" && digit4_Roman == "")
                             || digit4_Roman == "M" || digit4_Roman == "MM" || digit4_Roman == "MMM")
                        {
                            onDisplay_Roman = "ⅭⅭ" + digit9_Roman + digit8_Roman + digit7_Roman + "ↃↃ " 
                                            + digit6_Roman + digit5_Roman + digit4_Roman
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("ⅭⅭ and ↃↃ");
                            script2_largeNumber = true;
                        }
                        else
                        {
                            onDisplay_Roman = "ⅭⅭ" + digit9_Roman + digit8_Roman + digit7_Roman + "ↃↃ " 
                                            + 'Ⅽ' + digit6_Roman + digit5_Roman + digit4_Roman + "Ↄ "
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("Ⅽ and Ↄ, and ⅭⅭ and ↃↃ");
                            script3_largeNumber = true;
                        }

                        break;
                }

                // If the number has decimals, the nearest Roman fraction will be added to the Roman numeral
                ConvertFraction(result);

                // Update display
                UpdateDisplay_Roman(onDisplay_Roman);
            }
        }

        // Create replacement lists
        List<string> replacementList1;
        List<string> replacementList2;
        List<string> replacementList3;
        List<string> replacementList4;
        List<string> replacementList5;

        private void CreateReplacementLists()
        {
            replacementList1 = new List<string>()
            {  "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" };

            replacementList2 = new List<string>()
            { "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" };

            replacementList3 = new List<string>()
            {  "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" };

            replacementList4 = new List<string>()
            { "", "M", "MM", "MMM", "IV", "V", "VI", "VII", "VIII", "IX" };

            replacementList5 = new List<string>()
            { "", "․", "‥", "…", "⸬", "⁙", "S", "S․", "S‥", "S…", "S⸬", "S⁙" };
        }

        // Convert digit
        string digit1_Roman;
        string digit2_Roman;
        string digit3_Roman;
        string digit4_Roman;
        string digit5_Roman;
        string digit6_Roman;
        string digit7_Roman;
        string digit8_Roman;
        string digit9_Roman;
        string digit10_Roman;

        private void ConvertDigit(byte digitNr)
        {
            // Convert digit:
            // The number of the selected digit(1-10), in the numberArray, is compared to the numbers 0 to 9(i).
            // The matching instance number(i) is then used to select the corresponding Roman numeral in the correct replacement list.

            // Convert digit number 1
            if (digitNr == 1)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[0] == i)
                    { digit1_Roman = replacementList1[i]; UpdateNumber_Roman(digit1_Roman); }
                }
            }

            // Convert digit number 2
            if (digitNr == 2)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[1] == i)
                    { digit2_Roman = replacementList2[i]; UpdateNumber_Roman(digit2_Roman); }
                }
            }

            // Convert digit number 3
            if (digitNr == 3)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[2] == i)
                    { digit3_Roman = replacementList3[i]; UpdateNumber_Roman(digit3_Roman); }
                }
            }

            // Convert digit number 4
            if (digitNr == 4)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[3] == i)
                    {
                        if (numOfDigits == 4 || numOfDigits == 7 || numOfDigits == 10)
                        { digit4_Roman = replacementList4[i]; UpdateNumber_Roman(digit4_Roman); }
                        else
                        { digit4_Roman = replacementList1[i]; UpdateNumber_Roman(digit4_Roman); }
                    }
                }
            }

            // Convert digit number 5
            if (digitNr == 5)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[4] == i)
                    { digit5_Roman = replacementList2[i]; UpdateNumber_Roman(digit5_Roman); }
                }
            }

            // Convert digit number 6
            if (digitNr == 6)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[5] == i)
                    { digit6_Roman = replacementList3[i]; UpdateNumber_Roman(digit6_Roman); }
                }
            }

            // Convert digit number 7
            if (digitNr == 7)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[6] == i)
                    { digit7_Roman = replacementList1[i]; UpdateNumber_Roman(digit7_Roman); }
                }
            }

            // Convert digit number 8
            if (digitNr == 8)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[7] == i)
                    { digit8_Roman = replacementList2[i]; UpdateNumber_Roman(digit8_Roman); }
                }
            }

            // Convert digit number 9
            if (digitNr == 9)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[8] == i)
                    { digit9_Roman = replacementList3[i]; UpdateNumber_Roman(digit9_Roman); }
                }
            }

            // Convert digit number 10
            if (digitNr == 10)
            {
                for (byte i = 0; i <= 9; i++)
                {
                    if (numberArray[9] == i)
                    { digit10_Roman = replacementList1[i]; UpdateNumber_Roman(digit10_Roman); }
                }
            }
        }

        // CONVERT FRACTIONS

        // COMMENT: The Romans used fractions in a twelve-tier system: 1/12, 2/12, 3/12, etc. The corresponding Roman numerals
        // are in 'replacementList5'. In the method below, the remaining decimals of the calculated Arabic result are rounded off 
        // to nearest fraction in the Roman counting system

        double fraction_0_12 = 0.0000;
        double fraction_1_12 = 0.0833;
        double fraction_2_12 = 0.1667;
        double fraction_3_12 = 0.2500;
        double fraction_4_12 = 0.3333;
        double fraction_5_12 = 0.4167;
        double fraction_6_12 = 0.5000;
        double fraction_7_12 = 0.5833;
        double fraction_8_12 = 0.6667;
        double fraction_9_12 = 0.7500;
        double fraction_10_12 = 0.8333;
        double fraction_11_12 = 0.9167;
        double fraction_12_12 = 1.0000;

        string fraction_Roman;
        byte elementWithLowestDifference;
        bool fractionIsEqual;

        private void ConvertFraction(double number)
        {
            // First create a list of chars to check if the number contains a dot, and thus decimals
            string num = number.ToString();
            char[] numbers = num.ToCharArray();
            List<char> numbers_Arabic = numbers.ToList();

            // If numbers contains a dot/decimals, do the fraction conversion trick
            
            if (numbers_Arabic.Contains('.'))
            {
                // Split the string into two parts
                string[] parts = number.ToString().Split('.');

                // Create the fraction that needs to be compared with the fractions in the twelve-tier system
                string fraction = "0." + parts[1];
                double fraction_Arabic = Convert.ToDouble(fraction);

                // Create a list of the fractions in the twelve-tier system (Arabic version, with decimals)
                List<double> fractions = new List<double>()
                {
                    fraction_0_12, fraction_1_12, fraction_2_12, fraction_3_12, fraction_4_12, fraction_5_12, fraction_6_12,
                    fraction_7_12, fraction_8_12, fraction_9_12, fraction_10_12, fraction_11_12, fraction_12_12
                };

                // Create array for storing all the calculated differences between the used fractions in the twelve-tier system
                // and the fraction in the calculation ('fraction_Arabic')
                double[] difference = new double[fractions.Count];

                // Calculate the difference with each possible fraction
                for (byte i = 0; i < fractions.Count; i++)
                {
                    difference[i] = fractions[i] - fraction_Arabic;
                    difference[i] = Math.Abs(difference[i]);  // Stores only the absolute values (no negative values)
                }

                // Determine the element in the array/list with the lowest difference from the fraction in the calculation ('fraction_Arabic')
              
                for (byte i = 0; i < difference.Length; i++)
                {
                    if (difference[i] == difference.Min())
                    {
                        elementWithLowestDifference = i;
                        if (difference[i] == 0) { fractionIsEqual = true; }
                        else { fractionIsEqual = false; }
                    }
                }

                // Determine the Roman fraction from the replacement list and update the Roman number
                fraction_Roman = replacementList5[elementWithLowestDifference];
                UpdateNumber_Roman(" " + fraction_Roman); // add extra space for readability

                // Make sure the right script of the Roman master is given
                if (!script1_largeNumber && !script2_largeNumber && !script3_largeNumber)
                {
                    if (fractionIsEqual == true) { ScriptRomanMaster("fraction(1)"); }

                    if (fractionIsEqual == false)
                    {
                        if (fraction_Arabic >= (fraction_1_12 / 2)) { ScriptRomanMaster("fraction(2)"); }
                        else { ScriptRomanMaster("fraction(3)"); onDisplay_Roman = "nulla"; }
                    }
                }
                else
                {
                    if (script1_largeNumber) { ScriptRomanMaster("large number(1) and fraction"); }
                    if (script2_largeNumber) { ScriptRomanMaster("large number(2) and fraction"); }
                    if (script3_largeNumber) { ScriptRomanMaster("large number(3) and fraction"); }
                }        
            }     
        }

        // SCRIPT ROMAN MASTER
        private void ScriptRomanMaster(string scriptType)
        {
            // Preset content alignment
            textBox_romanMaster.HorizontalContentAlignment = HorizontalAlignment.Center;

            switch (scriptType)
            {
                case "start":
                    textBox_romanMaster.Text =
                        "Welcome to the Roman Calculator!"
                        + Environment.NewLine
                        + "Feel free to calculate...";
                    break;

                case "after clearance":
                    textBox_romanMaster.Text =
                        "Welcome to the Roman Calculator!"
                        + Environment.NewLine
                        + "Feel free to calculate...";
                    break;

                case "number generated":
                    textBox_romanMaster.Text =
                        "YES! That's a nice number!";
                        break;

                case "< 0":
                    textBox_romanMaster.Text =
                        "We Romans don't have negative numbers.";
                    break;

                case "= 0":
                    textBox_romanMaster.Text =
                        "We Romans don't have a number for which you call zero.";
                    break;

                case "> 999999999":
                    textBox_romanMaster.Text =
                        "This number is WAY TOO LARGE for us Romans!";
                    break;

                case "Ⅽ and Ↄ":
                    textBox_romanMaster.Text =
                        "The number between Ⅽ and Ↄ is times one thousand.";
                    break;

                case "ⅭⅭ and ↃↃ":
                    textBox_romanMaster.Text =
                        "The number between ⅭⅭ and ↃↃ is times one million.";
                    break;

                case "Ⅽ and Ↄ, and ⅭⅭ and ↃↃ":
                    textBox_romanMaster.Text =
                       "The number between ⅭⅭ and ↃↃ is times one million and that between Ⅽ and Ↄ times one thousand.";
                    break;

                case "fraction(1)":
                    if (elementWithLowestDifference != 0 && elementWithLowestDifference != 12)
                    {
                        DetermineFraction_Arabic(); // Determine fraction_Arabic for in the text below
                        textBox_romanMaster.Text =
                        "The number calculated is not a whole number, it has a fraction in it. "
                        + Environment.NewLine
                        + $"The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}) is equal to the fraction calculated.";
                    }
                    else
                    {
                        textBox_romanMaster.Text =
                        "The number calculated is not a whole number, it has a fraction in it. "
                        + Environment.NewLine
                        + $"The Roman numeral given is equal to the fraction calculated.";
                    }
                    break;

                case "fraction(2)":
                    if (elementWithLowestDifference != 0 && elementWithLowestDifference != 12)
                    {
                       DetermineFraction_Arabic(); // Determine fraction_Arabic for in the text below
                       textBox_romanMaster.Text =
                       "The number calculated is not a whole number, it has a fraction in it. "
                       + Environment.NewLine
                       + $"The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}) is closest to the fraction calculated.";
                    }
                    else
                    {
                      textBox_romanMaster.Text =
                      "The number calculated is not a whole number, it has a fraction in it. "
                      + Environment.NewLine
                      + $"The Roman numeral given is closest to the fraction calculated.";
                    }
                    break;

                case "fraction(3)":
                    textBox_romanMaster.Text =
                        "The number calculated is not a whole number, it has a fraction in it. "
                        + Environment.NewLine
                        + "It is so close to what you call zero, that we Romans don't have a fraction for it.";
                    break;

                case "large number(1) and fraction":
                    DetermineFraction_Arabic(); // Deternine fraction_Arabic for in the text below
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses Ⅽ and Ↄ (times thousand) and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;

                case "large number(2) and fraction":
                    DetermineFraction_Arabic(); // Deternine fraction_Arabic for in the text below
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses ⅭⅭ and ↃↃ (times million) and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;

                case "large number(3) and fraction":
                    DetermineFraction_Arabic(); // Deternine fraction_Arabic for in the text below
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses Ⅽ and Ↄ (times thousand), ⅭⅭ and ↃↃ (times million) and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;

                default:
                    textBox_romanMaster.Text = string.Empty;
                    break;
            }
        }

        string fraction_Arabic_text;
        private void DetermineFraction_Arabic()
        {
            switch(elementWithLowestDifference)
            {
                case 1:
                    fraction_Arabic_text = "1/12";
                    break;

                case 2:
                    fraction_Arabic_text = "2/12";
                    break;

                case 3:
                    fraction_Arabic_text = "3/12";
                    break;

                case 4:
                    fraction_Arabic_text = "4/12";
                    break;

                case 5:
                    fraction_Arabic_text = "5/12";
                    break;

                case 6:
                    fraction_Arabic_text = "6/12";
                    break;

                case 7:
                    fraction_Arabic_text = "7/12";
                    break;

                case 8:
                    fraction_Arabic_text = "8/12";
                    break;

                case 9:
                    fraction_Arabic_text = "9/12";
                    break;

                case 10:
                    fraction_Arabic_text = "10/12";
                    break;

                case 11:
                    fraction_Arabic_text = "11/12";
                    break;
            }
        }

        // UPDATE STATUS
        bool previousButton_number = false;
        bool previousButton_operation = false;
        bool previousButton_equals = false;

        private void UpdateStatus(string newStatus)
        {
            switch (newStatus)
            {
                case "number":
                    previousButton_number = true;
                    previousButton_operation = false;
                    previousButton_equals = false;
                    break;

                case "operation":
                    previousButton_operation = true;
                    previousButton_number = false;
                    previousButton_equals = false;
                    break;

                case "equals":
                    previousButton_equals = true;
                    previousButton_operation = false;
                    previousButton_number = false;
                    operation = string.Empty; // reset operation type to null
                    break;

                default:
                    previousButton_number = false;
                    previousButton_operation = false;
                    previousButton_equals = false;
                    break;    
            }
        }


        // CLEAR BUTTONS
      
        // ALL CLEAR
        private void Button_allClear_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ClearAndResetAll();
        }

        private void ClearAndResetAll()
        {
            onDisplay_Roman = string.Empty;
            UpdateDisplay_Roman("nulla");

            onDisplay_Arabic = string.Empty;
            UpdateDisplay_Arabic("0");
            number_Arabic = 0;

            value1 = 0;
            operation = string.Empty;

            UpdateStatus(string.Empty);
            ScriptRomanMaster("after clearance");
            EnableButtons();
        }

        // CLEAR (last input only)
        private void Button_clear_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (previousButton_number)
            {
                onDisplay_Roman = string.Empty;
                UpdateDisplay_Roman(onDisplay_Roman);

                onDisplay_Arabic = string.Empty;
                UpdateDisplay_Arabic("0");

                UpdateStatus(string.Empty);
                ScriptRomanMaster(string.Empty);
                EnableButtons();
            }

            if (previousButton_operation)
            {
                operation = string.Empty;

                UpdateStatus(string.Empty);
                ScriptRomanMaster(string.Empty);
                EnableButtons();
            }

            if (previousButton_equals)
            {
                ClearAndResetAll();
            }       
        }
    }
}























































































// ADDITIONAL CODE NOT USED ANYMORE

/*
    case "ⅭⅭⅭ and ↃↃↃ":
                    textBox_romanMaster.Text =
                        "The number between ⅭⅭⅭ and ↃↃↃ is times one billion.";
                    break;

    case "Ⅽ and Ↄ, and ⅭⅭⅭ and ↃↃↃ":
                    textBox_romanMaster.Text =
                       "The number between ⅭⅭⅭ and ↃↃↃ is times one billion and that between Ⅽ and Ↄ times one thousand.";
                    break;

                case "ⅭⅭ and ↃↃ, and ⅭⅭⅭ and ↃↃↃ":
                    textBox_romanMaster.Text =
                       "The number between ⅭⅭⅭ and ↃↃↃ is times one billion and that between ⅭⅭ and ↃↃ times one million.";
                    break;

                case "Ⅽ and Ↄ, and ⅭⅭ and ↃↃ, and ⅭⅭⅭ and ↃↃↃ":
                    textBox_romanMaster.Text =
                       "The number between ⅭⅭⅭ and ↃↃↃ times one billion, that between ⅭⅭ and ↃↃ is times one million and "
                       + "that between Ⅽ and Ↄ times one thousand.";
                    break;


             case "large number(3) and fraction":
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses ⅭⅭⅭ and ↃↃↃ (times billion) and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;

      case "large number(5) and fraction":
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses Ⅽ and Ↄ (times thousand), ⅭⅭⅭ and ↃↃↃ (times billion) and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;

                case "large number(6) and fraction":
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses ⅭⅭ and ↃↃ (times million), ⅭⅭⅭ and ↃↃↃ (times billion) and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;

                case "large number(7) and fraction":
                    textBox_romanMaster.Text =
                      "You've calculated a complex number!"
                       + Environment.NewLine
                       + $"It uses Ⅽ and Ↄ (times thousand), ⅭⅭ and ↃↃ (times million), ⅭⅭⅭ and ↃↃↃ (times billion)" +
                       $" and The Roman fraction {fraction_Roman} (= {fraction_Arabic_text}).";
                    break;





    */




/*
 * 

                    case 10:

                        ConvertDigit(1); ConvertDigit(2); ConvertDigit(3); ConvertDigit(4); ConvertDigit(5);
                        ConvertDigit(6); ConvertDigit(7); ConvertDigit(8); ConvertDigit(9); ConvertDigit(10);

                        if ((digit9_Roman == "" && digit8_Roman == "" && digit7_Roman == "" 
                             && (digit6_Roman != "" || digit7_Roman != "" || digit6_Roman != "")

                             || digit4_Roman == "M" || digit4_Roman == "MM" || digit4_Roman == "MMM")
                        {
                            onDisplay_Roman = "ⅭⅭⅭ" + digit10_Roman + "ⅭⅭⅭ " 
                                            + digit9_Roman + digit8_Roman + digit7_Roman +
                                            + 'Ⅽ' + digit6_Roman + digit5_Roman + digit4_Roman + "Ↄ "
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("Ⅽ and Ↄ, and ⅭⅭⅭ and ↃↃↃ");
                        }

                        else if ((digit6_Roman == "" && digit5_Roman == "" && digit4_Roman == "")
                                 || digit4_Roman == "M" || digit4_Roman == "MM" || digit4_Roman == "MMM")
                        {
                            onDisplay_Roman = "ⅭⅭⅭ" + digit10_Roman + "ⅭⅭⅭ "
                                        + digit9_Roman + digit8_Roman + digit7_Roman
                                        + digit6_Roman + digit5_Roman + digit4_Roman
                                        + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("ⅭⅭⅭ and ↃↃↃ");
                        }

                        else if ((digit6_Roman == "" && digit5_Roman == "" && digit4_Roman == "")
                                  || digit4_Roman == "M" || digit4_Roman == "MM" || digit4_Roman == "MMM")
                        {
                            onDisplay_Roman = "ⅭⅭⅭ" + digit10_Roman + "ⅭⅭⅭ "
                                            + "ⅭⅭ" + digit9_Roman + digit8_Roman + digit7_Roman + "ↃↃ "
                                            + digit6_Roman + digit5_Roman + digit4_Roman
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("ⅭⅭ and ↃↃ, and ⅭⅭⅭ and ↃↃↃ");
                        }
                        else
                        {
                            onDisplay_Roman = "ⅭⅭⅭ" + digit10_Roman + "ⅭⅭⅭ "
                                            + "ⅭⅭ" + digit9_Roman + digit8_Roman + digit7_Roman + "ↃↃ "
                                            + 'Ⅽ' + digit6_Roman + digit5_Roman + digit4_Roman + "Ↄ "
                                            + digit3_Roman + digit2_Roman + digit1_Roman;
                            ScriptRomanMaster("Ⅽ and Ↄ, and ⅭⅭ and ↃↃ, and ⅭⅭⅭ and ↃↃↃ");
                        }

                        break;
                        */






/*
            string[] parts = number.Split('.');
            char[] charArray = parts[0].ToCharArray();
            Array.Reverse(charArray);
            byte length = Convert.ToByte(charArray.Length);

            List<char> charList = new List<char>();

            bool check1 = false;
            bool check2 = false;
            bool check3 = false;
            bool check4 = false;
            bool check5 = false;
            bool check6 = false;
            bool check7 = false;
            bool check8 = false;
            bool check9 = false;
            bool check10 = false;
            bool check11 = false;
            bool check12 = false;
            bool check13 = false;
            bool check14 = false;
            bool check15 = false;
            bool check16 = false;
            bool check17 = false;
            bool check18 = false;
            bool check19 = false;
            bool check20 = false;
            bool check21 = false;
            bool check22 = false;
            bool check23 = false;
            bool check24 = false;

            foreach (char c in charArray)
            {
                if (length >= 1 && check1 == false) { if (c == charArray[0]) { charList.Add(charArray[0]); check1 = true; } }
                if (length >= 2 && check2 == false) { if (c == charArray[1]) { charList.Add(charArray[1]); check2 = true; } }
                if (length >= 3 && check3 == false) { if (c == charArray[2]) { charList.Add(charArray[2]); charList.Add(','); check3 = true; } }
                if (length >= 4 && check4 == false) { if (c == charArray[3]) { charList.Add(charArray[3]); check4 = true; } }
                if (length >= 5 && check5 == false) { if (c == charArray[4]) { charList.Add(charArray[4]); check5 = true; } }
                if (length >= 6 && check6 == false) { if (c == charArray[5]) { charList.Add(charArray[5]); charList.Add(','); check6 = true; } }
                if (length >= 7 && check7 == false) { if (c == charArray[6]) { charList.Add(charArray[6]); check7 = true; } }
                if (length >= 8 && check8 == false) { if (c == charArray[7]) { charList.Add(charArray[7]); check8 = true; } }
                if (length >= 9 && check9 == false) { if (c == charArray[8]) { charList.Add(charArray[8]); charList.Add(','); check9 = true; } }
                if (length >= 10 && check10 == false) { if (c == charArray[9]) { charList.Add(charArray[9]); check10 = true; } }
                if (length >= 11 && check11 == false) { if (c == charArray[10]) { charList.Add(charArray[10]); check11 = true; } }
                if (length >= 12 && check12 == false) { if (c == charArray[11]) { charList.Add(charArray[11]); charList.Add(','); check12 = true; } }
                if (length >= 13 && check13 == false) { if (c == charArray[12]) { charList.Add(charArray[12]); check13 = true; } }
                if (length >= 14 && check14 == false) { if (c == charArray[13]) { charList.Add(charArray[13]); check14 = true; } }
                if (length >= 15 && check15 == false) { if (c == charArray[14]) { charList.Add(charArray[14]); charList.Add(','); check15 = true; } }
                if (length >= 16 && check16 == false) { if (c == charArray[15]) { charList.Add(charArray[15]); check16 = true; } }
                if (length >= 17 && check17 == false) { if (c == charArray[16]) { charList.Add(charArray[16]); check17 = true; } }
                if (length >= 18 && check18 == false) { if (c == charArray[17]) { charList.Add(charArray[17]); charList.Add(','); check18 = true; } }
                if (length >= 19 && check19 == false) { if (c == charArray[18]) { charList.Add(charArray[18]); check19 = true; } }
                if (length >= 20 && check20 == false) { if (c == charArray[19]) { charList.Add(charArray[19]); check20 = true; } }
                if (length >= 21 && check21 == false) { if (c == charArray[20]) { charList.Add(charArray[20]); charList.Add(','); check21 = true; } }
                if (length >= 22 && check22 == false) { if (c == charArray[21]) { charList.Add(charArray[21]); check22 = true; } }
                if (length >= 23 && check23 == false) { if (c == charArray[22]) { charList.Add(charArray[22]); check23 = true; } }
                if (length >= 24 && check24 == false) { if (c == charArray[23]) { charList.Add(charArray[23]); charList.Add(','); check24 = true; } }
            }

            charArray = charList.ToArray();
            Array.Reverse(charArray);

            number = new string(charArray);
            */

