﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Contributie_Sportvereniging
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            label_contributionToBePaid.Visibility = Visibility.Collapsed;
        }

        private void LoadListOfDayNumbers(object sender)
        {
            // Declaration of the list 'dayNumbers'
            List<string> listOfdayNumbers = new List<string>();

            // Assignment 1st list item (title)
            listOfdayNumbers.Add("dag");

            // Assignment all days of the month
            for (int i = 1; i <= 31; i++)
            {
                listOfdayNumbers.Add(i.ToString());
            }

            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfdayNumbers;

            // Make the first item selected.
            comboBox.SelectedIndex = 0; 
        }

        private void LoadListOfMonths(object sender)
        {
            // Declaration of the list 'dayNumbers'
            List<string> listOfMonths = new List<string>
            { "maand", "januari", "februari", "maart", "april", "mei", "juni",
              "juli", "augustus", "september", "oktober", "november", "december"};

            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfMonths;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void LoadListOfYears(object sender)
        {
            // Declaration of the list 'dayNumbers'
            List<string> listOfYears = new List<string>();

            // Assignment 1st list item (title)
            listOfYears.Add("jaar");

            // Assignment of last 100 years
            int year = DateTime.Now.Year;
            for (int i = year; i >= year - 100; i--)
            {
                listOfYears.Add(i.ToString());
            }
            // Get the combobox reference.
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List.
            comboBox.ItemsSource = listOfYears;

            // Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        // LOAD COMBOBOXES
        private void ComboBox_birthDate_day_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfDayNumbers(sender);
        }

        private void ComboBox_birthDate_month_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfMonths(sender);
        }

        private void ComboBox_birthDate_year_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfYears(sender);
        }

        private void ComboBox_memberSince_day_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfDayNumbers(sender);
        }

        private void ComboBox_memberSince_month_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfMonths(sender);
        }

        private void ComboBox_memberSince_year_Loaded(object sender, RoutedEventArgs e)
        {
            LoadListOfYears(sender);
        }

        private void ComboBox_yearOfContribution_Loaded(object sender, RoutedEventArgs e)
        {
            // Declaration of the list 'dayNumbers'
            List<string> listOfYears = new List<string>();

            // Assignment of last 100 years
            DateTime today = DateTime.Now;
            int year = today.Year;

            DateTime startOfNewSeason = new DateTime(today.Year, 9, 1);
            if (today > startOfNewSeason)
            {
                year += 1;  // This makes sure that there is always one season later than the current season
                            // that can be selected in the combobox
            }

            for (int i = year; i >= year - 10; i--)
            {
                int j = i + 1;
                listOfYears.Add(i.ToString() + "/" + j.ToString());
            }

            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Assign the ItemsSource to the List
            comboBox.ItemsSource = listOfYears;

            // Set selected combobox item
            comboBox.SelectedIndex = 1;
        }

        // DETERMINE AGE
        int age;
        bool inputIsCorrect = true;
        DateTime birthdate;
        private void DetermineAge()
        {
            // Check if date is valid. 
            // If true, determine birthdate and age. If false, give error message.
            try
            {
                // Determine year
                int year = Convert.ToInt16(comboBox_birthDate_year.Text);

                // Determine month (with selected index number of combobox)
                int month = Convert.ToInt16(comboBox_birthDate_month.SelectedIndex);

                // Determine day
                int day = Convert.ToInt16(comboBox_birthDate_day.Text);

                // Check birthdate
                birthdate = new DateTime(year, month, day);

                // Determine contribution year and start of season (set at the 1st of september every year)
                int yearOfContribution = Convert.ToInt16(comboBox_yearOfContribution.Text.Substring(0, 4));
                DateTime startOfSeason = new DateTime(yearOfContribution, 9, 1);

                // Determine age
                age = startOfSeason.Year - birthdate.Year;

                if (startOfSeason.DayOfYear < birthdate.DayOfYear)
                {
                    age -= 1;
                }

                // Check if member is at least 4 years old
                if (age < 4)
                {
                    inputIsCorrect = false;
                    MessageBox.Show("De ingevoerde leeftijd ligt onder de 4 jaar. De minimumleeftijd voor leden is 4 jaar.",
                                    "Leeftijd onder minimumleeftijd");
                }
            }
            catch (Exception)
            {
                if (inputIsCorrect)
                {
                    MessageBox.Show("De geboortedatum is niet of onjuist ingevoerd. Voer een geldige datum in.",
                                    "Geen of onjuiste invoer");
                }
                inputIsCorrect = false;
            }
        }

        // DETERMINE YEARS OF MEMBERSHIP
        int yearsOfMembership;
        private void DetermineYearsOfMembership()
        {
            // Check if date is valid. 
            // If true, determine birthdate and age. If false, give error message.
            try
            {
                // Determine year
                int year = Convert.ToInt16(comboBox_memberSince_year.Text);

                // Determine month (with selected index number of combobox)
                int month = Convert.ToInt16(comboBox_memberSince_month.SelectedIndex);

                // Determine day
                int day = Convert.ToInt16(comboBox_memberSince_day.Text);

                // Check startdate membership 
                DateTime startdateMembership = new DateTime(year, month, day);

                // Determine contribution year and start of season (set at the 1st of september every year)
                int yearOfContribution = Convert.ToInt16(comboBox_yearOfContribution.Text.Substring(0, 4));
                DateTime startOfSeason = new DateTime(yearOfContribution, 9, 1);

                // Determine full years of membership
                yearsOfMembership = startOfSeason.Year - startdateMembership.Year;
                if (startOfSeason.DayOfYear < startdateMembership.DayOfYear)
                {
                    yearsOfMembership -= 1;
                }

                // Check if entered start date of membership is later than entered birthdate
                if (startdateMembership < birthdate)
                {
                    inputIsCorrect = false;
                    MessageBox.Show("De ingevoerde startdatum van lidmaatschap ligt vóór de geboortedatum. Voer een juiste datum in.", 
                                    "Onjuiste invoer");
                }

                // Check if entered start date of membership is later than entered birthdate
                if (startdateMembership > birthdate
                    && startdateMembership < birthdate.AddYears(4))
                {
                    inputIsCorrect = false;
                    MessageBox.Show("De minimumleeftijd voor leden is 4 jaar. De ingevoerde startdatum van lidmaatschap ligt minder dan " +
                                    "4 jaar na de geboortedatum. Voer een juiste datum in.", "Onjuiste invoer");
                }
            }
            catch (Exception)
            {
                if (inputIsCorrect)
                {
                    MessageBox.Show("De startdatum van lidmaatschap is niet of onjuist ingevoerd. Voer een geldige datum in.",
                                    "Geen of onjuiste invoer");
                }  
                inputIsCorrect = false;
            }
        }

        // COUNT NUMBER OF SELECTED SPORTS
        int numOfSports;
        private void CountNumberOfSports()
        {
            numOfSports = 0;

            if (checkBox_football.IsChecked == true)   { numOfSports++; }
            if (checkBox_volleyball.IsChecked == true) { numOfSports++; }
            if (checkBox_basketball.IsChecked == true) { numOfSports++; }
            if (checkBox_handball.IsChecked == true)   { numOfSports++; }
            if (checkBox_athletics.IsChecked == true)  { numOfSports++; }
        }

        // CALCULATE BUTTON
        double contribution;
        private void Label_calculateButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // Preset
            inputIsCorrect = true;
            
            // Check if first & last name are given
            string firstName = textBox_firstName.Text;
            string lastName = textBox_lastName.Text;

            if (firstName == "" || lastName == "")
            {
                if (firstName == "" && lastName == "")
                {
                    inputIsCorrect = false;
                    MessageBox.Show("Voer een voor- en achternaam in.", "Geen invoer voor- en achternaam");
                }
                else
                {
                    if (firstName == "")
                    {
                        inputIsCorrect = false;
                        MessageBox.Show("Voer een voornaam in.", "Geen invoer voornaam");
                    }

                    if (lastName == "")
                    {
                        inputIsCorrect = false;
                        MessageBox.Show("Voer een achternaam in.", "Geen invoer achternaam");
                    }
                }
            }

            // Determine and check age 
            DetermineAge();

            // Determine years of membership
            DetermineYearsOfMembership();

            // Count number of sports practised
            if (inputIsCorrect)
            {
                CountNumberOfSports();
                if (numOfSports == 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Volgens de ingevoerde gegevens beoefend {firstName} {lastName} " +
                                                              "niet één of meerdere sporten. Is dit juist?",
                                                              "Invoer beoefende sporten", MessageBoxButton.YesNo);

                    if (result == MessageBoxResult.Yes)
                    {
                        MessageBox.Show($"{firstName} {lastName} betaalt contributie enkel als ondersteunend lid, " +
                                        "zonder dat hij/zij sporten beoefent.", "Invoer geldig voor ondersteunend lid");
                    }
                    else
                    {
                        MessageBox.Show($"Vink aan welke sporten door {firstName} {lastName} worden beoefend en druk opnieuw op " +
                                        "de knop 'Bereken'. Zo niet, dan wordt niet de juiste contributie berekend",
                                        "Invoer beoefende sporten");
                    }
                }

                // Calculate contribution
                if (inputIsCorrect)
                {
                    // Base contribution
                    contribution = 40.00;

                    // Extra contribution, depending on number of sports being practiced
                    if (numOfSports >= 1 && numOfSports <= 2)
                    {
                        contribution += numOfSports * 25.00;
                    }

                    else if (numOfSports >= 3 && numOfSports <= 4)
                    {
                        contribution += numOfSports * 22.00;
                    }

                    else if (numOfSports == 5)
                    {
                        contribution += numOfSports * 20.00;
                    }

                    // Determine age discount
                    if (age < 18 || age >= 40)
                    {
                        contribution *= 0.9;
                    }

                    // Determine (extra) discount with respect to the number of full membership years
                    if (yearsOfMembership >= 5)
                    {
                        contribution *= 0.95;
                    }

                    // Print/show contribution to be paid
                    string year = comboBox_yearOfContribution.Text;
                    string contributionToBePaid = contribution.ToString("C", CultureInfo.GetCultureInfo("nl-NL"));

                    label_contributionToBePaid.Content =
                        $"Te betalen contributie {year} door {firstName} {lastName}: {contributionToBePaid}";

                    label_contributionToBePaid.Visibility = Visibility.Visible;
                }
                else
                {
                    // Ignore
                }
            }
        }

        // CHANGE FOREGROUND COLOR COMBOBOX AT SELECTION CHANGE
        private void ChangeForeGroundColorComboBoxAtSelectionChange(object sender)
        {
            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Change foreground color
            if (comboBox.SelectedIndex != 0)
            {
                comboBox.Foreground = new SolidColorBrush(Colors.Black);
            }
            else
            {
                comboBox.Foreground = new SolidColorBrush(Colors.DimGray);
            }
        }

        private void ComboBox_birthDate_day_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_birthDate_month_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_birthDate_year_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_memberSince_day_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_memberSince_month_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        private void ComboBox_memberSince_year_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtSelectionChange(sender);
        }

        // CHANGE FOREGROUND COLOR COMBOBOXES AT MOUSE CAPTURE
        private void ChangeForeGroundColorComboBoxAtMouseCapture(object sender, Color color)
        {
            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Change foreground color
            comboBox.Foreground = new SolidColorBrush(color);
        }

        private void ComboBox_birthDate_day_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
        }

        private void ComboBox_birthDate_month_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
        }

        private void ComboBox_birthDate_year_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
        }

        private void ComboBox_memberSince_day_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
        }

        private void ComboBox_memberSince_month_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
        }

        private void ComboBox_memberSince_year_GotMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtMouseCapture(sender, Colors.Black);
        }

        // CHANGE FOREGROUND COLOR COMBOBOXES AT LOST MOUSE CAPTURE
        private void ChangeForeGroundColorComboBoxAtLostMouseCapture(object sender, Color color)
        {
            // Get the combobox reference
            var comboBox = sender as ComboBox;

            // Change foreground color
            if (comboBox.SelectedIndex == 0)
            {
                comboBox.Foreground = new SolidColorBrush(color);
            }
        }

        private void ComboBox_birthDate_day_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_birthDate_month_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_birthDate_year_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_memberSince_day_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_memberSince_month_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        private void ComboBox_memberSince_year_LostMouseCapture(object sender, MouseEventArgs e)
        {
            ChangeForeGroundColorComboBoxAtLostMouseCapture(sender, Colors.DimGray);
        }

        // CHANGE CARETBRUSH COLOR
        private void ChangeCaretBrushColor(Color color)
        {
            textBox_firstName.CaretBrush = new SolidColorBrush(color);
            textBox_lastName.CaretBrush = new SolidColorBrush(color);
        }

        private void TextBox_firstName_GotFocus(object sender, RoutedEventArgs e)
        {
            ChangeCaretBrushColor(Colors.Black);
        }

        private void TextBox_firstName_LostFocus(object sender, RoutedEventArgs e)
        {
            ChangeCaretBrushColor(Colors.White);
        }

        private void TextBox_lastName_GotFocus(object sender, RoutedEventArgs e)
        {
            ChangeCaretBrushColor(Colors.Black);
        }

        private void TextBox_lastName_LostFocus(object sender, RoutedEventArgs e)
        {
            ChangeCaretBrushColor(Colors.White);
        }
    }
}
